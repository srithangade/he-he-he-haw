import { ArrowLeft, MessageSquare, Clock, Users, TrendingUp, CheckCircle, Zap, DollarSign } from "lucide-react";
import { Link } from "react-router-dom";
import ScrollAnimation from "../components/ScrollAnimation";

const AIChatbots = () => {
  const benefits = [
    {
      icon: <Clock className="w-8 h-8" />,
      title: "Instant Response",
      description: "Provide immediate answers to customer questions 24/7, improving satisfaction and reducing bounce rates."
    },
    {
      icon: <DollarSign className="w-8 h-8" />,
      title: "Cost Reduction",
      description: "Reduce customer service costs by up to 60% while handling unlimited conversations simultaneously."
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Lead Generation",
      description: "Engage website visitors proactively, qualify leads, and guide them through your sales funnel."
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: "Increased Conversions",
      description: "Studies show chatbots can increase conversion rates by up to 67% through personalized interactions."
    }
  ];

  const process = [
    {
      step: "1",
      title: "Business Analysis",
      description: "We analyze your business, common questions, and customer journey to design the perfect chatbot flow."
    },
    {
      step: "2",
      title: "Custom Training",
      description: "Train the AI on your specific products, services, and brand voice for authentic conversations."
    },
    {
      step: "3",
      title: "Integration",
      description: "Seamlessly integrate with your website, CRM, and existing tools for automated lead management."
    },
    {
      step: "4",
      title: "Optimization",
      description: "Continuous monitoring and optimization based on real conversation data and performance metrics."
    }
  ];

  const features = [
    "Natural language understanding",
    "Multi-language support",
    "Lead qualification & scoring",
    "Appointment scheduling",
    "CRM integration",
    "Live chat handoff",
    "Analytics & insights",
    "Custom conversation flows",
    "E-commerce integration",
    "FAQ automation"
  ];

  const useCases = [
    {
      title: "Customer Support",
      description: "Handle common questions, troubleshooting, and support requests instantly.",
      example: "Product information, shipping status, return policies."
    },
    {
      title: "Lead Qualification",
      description: "Identify and qualify potential customers before passing to sales teams.",
      example: "Budget qualification, needs assessment, contact collection."
    },
    {
      title: "Sales Assistance",
      description: "Guide customers through product selection and purchasing decisions.",
      example: "Product recommendations, pricing information, feature comparisons."
    },
    {
      title: "Appointment Booking",
      description: "Schedule meetings, consultations, and service appointments automatically.",
      example: "Calendar integration, availability checking, reminder systems."
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="text-center-all space-y-8">
            <ScrollAnimation>
              <Link to="/services" onClick={() => window.scrollTo(0, 0)} className="inline-flex items-center text-primary mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Services
              </Link>
              <h1 className="text-4xl md:text-5xl font-bold">AI Chatbots</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Intelligent conversational interfaces that engage visitors, answer questions instantly, 
                and convert browsers into customers 24/7 with human-like interactions.
              </p>
              <p className="text-sm text-muted-foreground max-w-3xl mx-auto">
                Learn about our <Link to="/security" onClick={() => window.scrollTo(0, 0)} className="no-underline">Security & Compliance</Link> approach.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Problem & Solution */}
      <section className="section-padding">
        <div className="container-width">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation>
              <div className="space-y-6">
                <MessageSquare className="w-16 h-16 text-primary" />
                <h2 className="text-3xl font-bold">Why Your Website Needs AI Chatbots</h2>
                <div className="space-y-4">
                  <p className="text-muted-foreground leading-relaxed">
                    <strong className="text-foreground">79% of website visitors</strong> leave without taking action when they can't find answers quickly. 
                    Traditional contact forms and phone calls create friction in the customer journey.
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    Our AI Chatbots provide instant, intelligent responses that keep visitors engaged, 
                    answer their questions immediately, and guide them toward becoming customers.
                  </p>
                </div>
              </div>
            </ScrollAnimation>
            
            <ScrollAnimation>
              <div className="bg-card rounded-lg p-8 border border-border">
                <h3 className="text-2xl font-semibold mb-6 text-center">Impact Statistics</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">Increase in lead generation</span>
                    <span className="text-2xl font-bold text-primary">67%</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">Reduction in support costs</span>
                    <span className="text-2xl font-bold text-primary">60%</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">Customer satisfaction increase</span>
                    <span className="text-2xl font-bold text-primary">90%</span>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Transform Your Customer Experience</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Provide exceptional customer service and capture more leads with intelligent automation.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => (
              <ScrollAnimation key={index}>
                <div className="service-card">
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary flex-shrink-0">
                      {benefit.icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-3">{benefit.title}</h3>
                      <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
                    </div>
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Common Utilize Cases</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                See how AI chatbots can transform different aspects of your business operations.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {useCases.map((useCase, index) => (
              <ScrollAnimation key={index}>
                <div className="service-card">
                  <h3 className="text-xl font-semibold mb-3">{useCase.title}</h3>
                  <p className="text-muted-foreground leading-relaxed mb-4">{useCase.description}</p>
                  <div className="bg-secondary p-4 rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      <strong className="text-foreground">Examples:</strong> {useCase.example}
                    </p>
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Implementation Process</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                From concept to deployment, we ensure your chatbot delivers results from day one.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <ScrollAnimation key={index}>
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto text-xl font-bold">
                    {step.step}
                  </div>
                  <h3 className="text-xl font-semibold">{step.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{step.description}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="section-padding">
        <div className="container-width">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation>
              <div className="space-y-6">
                <h2 className="text-3xl md:text-4xl font-bold">Advanced Capabilities</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Our AI chatbots are equipped with enterprise-grade features that ensure 
                  intelligent, contextual conversations that feel natural and helpful.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </ScrollAnimation>
            
            <ScrollAnimation>
              <div className="bg-card rounded-lg p-8 border border-border">
                <h3 className="text-2xl font-semibold mb-6 text-center">Pricing Information</h3>
                <div className="text-center space-y-4">
                  <Zap className="w-16 h-16 text-primary mx-auto" />
                  <p className="text-lg text-muted-foreground">
                    Pricing varies based on complexity, features, and integration requirements.
                  </p>
                  <p className="text-primary font-semibold">
                    Contact us for a personalized quote tailored to your specific needs.
                  </p>
                  <div className="mt-6">
                    <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                      Contact Us
                    </Link>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-8">
              <h2 className="text-3xl md:text-4xl font-bold">Ready to Engage Your Visitors?</h2>
              <p className="text-lg opacity-90 max-w-2xl mx-auto">
                Transform your website into a conversion machine with intelligent AI chatbots that work 24/7.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="bg-primary-foreground text-primary px-8 py-3 rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                  Start Conversation
                </Link>
                <Link to="/services" onClick={() => window.scrollTo(0, 0)} className="border border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary px-8 py-3 rounded-lg font-semibold transition-all duration-300">
                  View All Services
                </Link>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
};

export default AIChatbots;