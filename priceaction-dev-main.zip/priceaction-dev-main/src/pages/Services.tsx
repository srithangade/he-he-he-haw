import { Code, Bot, Smartphone, Database, TrendingUp, Megaphone, Palette } from "lucide-react";
import { Link } from "react-router-dom";
import ScrollAnimation from "../components/ScrollAnimation";
const Services = () => {
  const services = [{
    icon: <Code className="w-12 h-12" />,
    title: "Website & Mobile App Creation",
    description: "Custom-built digital solutions that drive engagement and conversions. We create responsive websites and mobile applications that perfectly align with your business goals and provide exceptional user experiences across all devices.",
    features: ["Responsive Design", "SEO Optimization", "E-commerce Integration", "Performance Optimization"],
    comingSoon: false
  }, {
    icon: <Bot className="w-12 h-12" />,
    title: "AI Agents",
    description: "24/7 intelligent phone agents that handle customer inquiries, schedule appointments, and qualify leads with human-like conversation skills. Never miss a potential customer call again with our advanced AI phone systems.",
    features: ["Natural Language Processing", "Call Routing", "Lead Qualification", "Appointment Scheduling"],
    comingSoon: false
  }, {
    icon: <Smartphone className="w-12 h-12" />,
    title: "AI Chatbots",
    description: "Intelligent conversational interfaces that engage website visitors, answer questions, and guide customers through their journey. Our chatbots integrate seamlessly with your existing systems and provide instant customer support.",
    features: ["Multi-language Support", "CRM Integration", "Learning Algorithms", "Analytics Dashboard"],
    comingSoon: false
  }, {
    icon: <Database className="w-12 h-12" />,
    title: "SAAS (Software as a Service)",
    description: "Scalable cloud-based software solutions tailored to your specific business needs. We develop comprehensive SAAS platforms that grow with your business and provide measurable value to your customers.",
    features: ["Cloud Infrastructure", "Subscription Management", "API Development", "Data Analytics"],
    comingSoon: false
  }, {
    icon: <TrendingUp className="w-12 h-12" />,
    title: "Business Scaling Through AI",
    description: "Comprehensive AI-powered strategies and tools that automate your business processes, optimize operations, and accelerate growth. Transform your business with intelligent automation that works 24/7.",
    features: ["Process Automation", "Predictive Analytics", "Performance Optimization", "Growth Strategies"],
    comingSoon: true
  }, {
    icon: <Megaphone className="w-12 h-12" />,
    title: "AI Ad Management",
    description: "Intelligent advertising campaigns that optimize themselves in real-time. Our AI systems analyze performance data, adjust targeting, and maximize your return on ad spend across all major platforms.",
    features: ["Real-time Optimization", "Multi-platform Management", "ROI Tracking", "Audience Targeting"],
    comingSoon: true
  }, {
    icon: <Palette className="w-12 h-12" />,
    title: "Logo and Campaign Design",
    description: "Professional branding and marketing design services that create memorable visual identities. From logos to complete marketing campaigns, we help your brand stand out in the digital landscape.",
    features: ["Brand Identity", "Marketing Materials", "Digital Assets", "Creative Strategy"],
    comingSoon: true
  }];
  return <div className="min-h-screen">
      {/* Hero Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="text-center-all space-y-8">
            <ScrollAnimation>
              <h1 className="text-4xl md:text-5xl font-bold">Our Services</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Comprehensive AI-powered solutions designed to automate your business, 
                accelerate growth, and create sustainable competitive advantages in the digital landscape.
              </p>
              <p className="text-sm text-muted-foreground">
                Learn how we protect your data in our {" "}
                <Link to="/security" onClick={() => window.scrollTo(0, 0)} className="no-underline">Security & Compliance</Link> page.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="section-padding">
        <div className="container-width">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {services.slice(0, 4).map((service, index) => <ScrollAnimation key={index}>
                <div className={`service-card ${service.comingSoon ? 'coming-soon-blur' : ''}`}>
                  {service.comingSoon && <div className="badge">
                      Coming Soon
                    </div>}
                  <div className={service.comingSoon ? 'content' : ''}>
                    <div className="flex items-start space-x-4 mb-6">
                      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary flex-shrink-0">
                        {service.icon}
                      </div>
                      <div className="flex-1">
                        <h3 className="text-2xl font-semibold mb-4">{service.title}</h3>
                      </div>
                    </div>
                    
                    <p className="text-muted-foreground leading-relaxed mb-6">
                      {service.description}
                    </p>

                    <div className="space-y-3 mb-6">
                      <h4 className="font-semibold text-sm uppercase tracking-wide">Key Features</h4>
                      <ul className="space-y-2">
                        {service.features.map((feature, featureIndex) => <li key={featureIndex} className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                            <span className="text-sm text-muted-foreground">{feature}</span>
                          </li>)}
                      </ul>
                    </div>

                    {!service.comingSoon && <Link to={service.title === "Website & Mobile App Creation" ? "/website-services" : service.title === "AI Agents" ? "/ai-call-agents" : service.title === "AI Chatbots" ? "/ai-chatbots" : service.title === "SAAS (Software as a Service)" ? "/saas-services" : "/contact"} onClick={() => window.scrollTo(0, 0)} className="bg-black text-white px-8 py-4 rounded-lg text-lg font-semibold hover:scale-105 transition-transform duration-300 w-full text-center">
                        Try Now →
                      </Link>}
                  </div>
                </div>
              </ScrollAnimation>)}
          </div>
          
          {/* Coming Soon Services - Last 3 centered */}
          <div className="flex justify-center mt-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-5xl">
              {services.slice(4).map((service, index) => <ScrollAnimation key={index + 4}>
                  <div className="service-card coming-soon-blur">
                    <div className="badge">
                      Coming Soon
                    </div>
                    <div className="content">
                      <div className="flex items-start space-x-4 mb-6">
                        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary flex-shrink-0">
                          {service.icon}
                        </div>
                        <div>
                          <h3 className="text-2xl font-semibold mb-2">{service.title}</h3>
                        </div>
                      </div>
                      
                      <p className="text-muted-foreground leading-relaxed mb-6">
                        {service.description}
                      </p>

                      <div className="space-y-3">
                        <h4 className="font-semibold text-sm uppercase tracking-wide">Key Features</h4>
                        <ul className="space-y-2">
                          {service.features.map((feature, featureIndex) => <li key={featureIndex} className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                              <span className="text-sm text-muted-foreground">{feature}</span>
                            </li>)}
                        </ul>
                      </div>
                    </div>
                  </div>
                </ScrollAnimation>)}
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Our Process</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                A streamlined approach that ensures your project is delivered on time, 
                on budget, and exceeds your expectations.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[{
            step: "01",
            title: "Discovery",
            description: "We analyze your business needs and identify automation opportunities."
          }, {
            step: "02",
            title: "Strategy",
            description: "Custom solution design tailored to your specific requirements."
          }, {
            step: "03",
            title: "Development",
            description: "Agile development with regular updates and client feedback."
          }, {
            step: "04",
            title: "Launch",
            description: "Deployment, training, and ongoing support for optimal performance."
          }].map((process, index) => <ScrollAnimation key={index}>
                <div className="text-center-all space-y-4">
                  <div className="w-16 h-16 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto text-xl font-bold">
                    {process.step}
                  </div>
                  <h3 className="text-xl font-semibold">{process.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{process.description}</p>
                </div>
              </ScrollAnimation>)}
          </div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-8">
              <h2 className="text-3xl md:text-4xl font-bold">Coding We Utilize</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Cutting-edge technologies and frameworks that power our AI solutions and ensure 
                scalable, reliable, and secure implementations.
              </p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 mt-12">
                {["React", "Node.js", "Python", "TensorFlow", "AWS", "MongoDB", "OpenAI", "Stripe", "Docker", "Firebase", "PostgreSQL", "Redis"].map((tech, index) => <div key={index} className="bg-card border border-border rounded-lg p-4 hover:shadow-elegant transition-all duration-300">
                    <div className="text-center-all font-semibold text-sm">{tech}</div>
                  </div>)}
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>;
};
export default Services;