import { ArrowLeft, Bot, Phone, Clock, TrendingUp, CheckCircle, Users, DollarSign } from "lucide-react";
import { Link } from "react-router-dom";
import ScrollAnimation from "../components/ScrollAnimation";
import IndustryAgentsSection from "../components/IndustryAgentsSection";

const AICallAgents = () => {
  const benefits = [
    {
      icon: <Clock className="w-8 h-8" />,
      title: "24/7 Availability",
      description: "Never miss a call again. Your AI agent works around the clock, capturing leads even when you're sleeping."
    },
    {
      icon: <DollarSign className="w-8 h-8" />,
      title: "Cost Savings",
      description: "Reduce staffing costs by up to 70% while handling unlimited calls simultaneously without additional overhead."
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Lead Capture",
      description: "Every missed call is a lost opportunity. Our AI ensures no potential customer slips through the cracks."
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: "Increased Revenue",
      description: "Studies show that 22% of missed calls result in lost customers. Capture 100% of your opportunities."
    }
  ];

  const process = [
    {
      step: "1",
      title: "Setup & Training",
      description: "We configure your AI agent with your business information, services, and frequently asked questions."
    },
    {
      step: "2",
      title: "Voice Customization",
      description: "Choose from professional voice options and customize the personality to match your brand."
    },
    {
      step: "3",
      title: "Integration",
      description: "Seamlessly integrate with your existing phone system and CRM for automatic lead tracking."
    },
    {
      step: "4",
      title: "Go Live",
      description: "Your AI agent starts handling calls immediately with real-time monitoring and optimization."
    }
  ];

  const features = [
    "Natural conversation flow",
    "Appointment scheduling",
    "Lead qualification",
    "Call routing to human agents",
    "CRM integration",
    "Real-time analytics",
    "Multi-language support",
    "Custom business responses"
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="text-center-all space-y-8">
            <ScrollAnimation>
              <Link to="/services" onClick={() => window.scrollTo(0, 0)} className="inline-flex items-center text-primary mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Services
              </Link>
              <h1 className="text-4xl md:text-5xl font-bold">AI Agents</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Revolutionary AI-powered phone agents that handle customer calls with human-like conversation, 
                never miss an opportunity, and work 24/7 to grow your business.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Problem & Solution */}
      <section className="section-padding">
        <div className="container-width">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation>
              <div className="space-y-6">
                <Bot className="w-16 h-16 text-primary" />
                <h2 className="text-3xl font-bold">The Cost of Missed Calls</h2>
                <div className="space-y-4">
                  <p className="text-muted-foreground leading-relaxed">
                    <strong className="text-foreground">22% of missed calls</strong> never call back, meaning you're losing potential customers every day. 
                    Traditional phone systems can't handle multiple calls simultaneously, and hiring staff for 24/7 coverage is expensive.
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    Our AI Agents solve this problem by providing unlimited concurrent call handling, 
                    perfect conversation quality, and round-the-clock availability at a fraction of the cost.
                  </p>
                </div>
              </div>
            </ScrollAnimation>
            
            <ScrollAnimation>
              <div className="bg-card rounded-lg p-8 border border-border">
                <h3 className="text-2xl font-semibold mb-6 text-center">Key Statistics</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">Missed calls that don't return</span>
                    <span className="text-2xl font-bold text-primary">22%</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">Average cost per missed lead</span>
                    <span className="text-2xl font-bold text-primary">$240</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">ROI with AI agents</span>
                    <span className="text-2xl font-bold text-primary">400%+</span>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Why Businesses Choose AI Agents</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Transform your phone system into a revenue-generating machine that works 24/7.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => (
              <ScrollAnimation key={index}>
                <div className="service-card">
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary flex-shrink-0">
                      {benefit.icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-3">{benefit.title}</h3>
                      <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
                    </div>
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">How AI Agents Work</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Our implementation process is designed for quick deployment and maximum effectiveness.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <ScrollAnimation key={index}>
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto text-xl font-bold">
                    {step.step}
                  </div>
                  <h3 className="text-xl font-semibold">{step.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{step.description}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation>
              <div className="space-y-6">
                <h2 className="text-3xl md:text-4xl font-bold">Advanced Features</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Our AI Agents come equipped with enterprise-grade features that ensure 
                  professional interactions and seamless integration with your business processes.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </ScrollAnimation>
            
            <ScrollAnimation>
              <div className="bg-card rounded-lg p-8 border border-border">
                <h3 className="text-2xl font-semibold mb-6 text-center">Pricing Information</h3>
                <div className="text-center space-y-4">
                  <Phone className="w-16 h-16 text-primary mx-auto" />
                  <p className="text-lg text-muted-foreground">
                    Pricing varies based on call volume, features, and customization requirements.
                  </p>
                  <p className="text-primary font-semibold">
                    Contact us for a personalized quote and see how much you can save.
                  </p>
                  <p className="text-sm text-muted-foreground">
                    See our <Link to="/security" onClick={() => window.scrollTo(0, 0)} className="no-underline">Security & Compliance</Link> for data protection details.
                  </p>
                  <div className="mt-6">
                    <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                      Contact Us
                    </Link>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      <IndustryAgentsSection />

      {/* CTA Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-8">
              <h2 className="text-3xl md:text-4xl font-bold">Ready to Stop Missing Calls?</h2>
              <p className="text-lg opacity-90 max-w-2xl mx-auto">
                Transform your phone system today and start capturing every opportunity with AI-powered call agents.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="bg-primary-foreground text-primary px-8 py-3 rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                  Get Started Today
                </Link>
                <Link to="/services" onClick={() => window.scrollTo(0, 0)} className="border border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary px-8 py-3 rounded-lg font-semibold transition-all duration-300">
                  View All Services
                </Link>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
};

export default AICallAgents;