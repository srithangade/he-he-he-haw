import { useEffect } from "react";
import ScrollAnimation from "../components/ScrollAnimation";
import { Shield, Lock, FileCheck, Server, Cloud, Database, UserCheck, MailWarning } from "lucide-react";

const Security = () => {
  useEffect(() => {
    document.title = "Security & Compliance - PriceAction";
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute(
        "content",
        "Security & Compliance at PriceAction: encryption, GDPR/CCPA, resilient infrastructure, backups, customer data controls, and security contacts."
      );
    }

    // GA4 event
    // Supports either gtag or dataLayer if present
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (window as any).gtag?.("event", "security_page_view");
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (window as any).dataLayer?.push?.({ event: "security_page_view" });
  }, []);

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: [
      {
        "@type": "Question",
        name: "How do you encrypt data?",
        acceptedAnswer: {
          "@type": "Answer",
          text:
            "We use industry-standard encryption in transit (TLS 1.2+) and at rest with provider-managed keys and periodic key rotations.",
        },
      },
      {
        "@type": "Question",
        name: "Which compliance frameworks do you align with?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "We follow GDPR and CCPA principles with data subject rights workflows (access, export, deletion).",
        },
      },
      {
        "@type": "Question",
        name: "What is your uptime and backup policy?",
        acceptedAnswer: {
          "@type": "Answer",
          text:
            "We deploy on reputable cloud providers with multi-zone redundancy, daily backups, and routine disaster recovery tests.",
        },
      },
    ],
  } as const;

  return (
    <div className="min-h-screen bg-background">
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />

      <section className="section-padding bg-secondary/40">
        <div className="container-width">
          <div className="text-center-all space-y-4 mb-4">
            <h1 className="text-4xl font-bold">Security & Compliance</h1>
            <p className="text-muted-foreground max-w-3xl mx-auto">
              Our security-first approach protects your data with modern encryption, privacy best practices,
              robust infrastructure, and transparent customer controls.
            </p>
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container-width grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Overview */}
          <ScrollAnimation>
            <article className="service-card p-6">
              <div className="flex items-start gap-3 mb-3">
                <Shield className="w-6 h-6 text-primary" aria-hidden="true" />
                <h2 className="text-xl font-semibold">Overview of Our Security Approach</h2>
              </div>
              <p className="text-muted-foreground">
                We adopt defense-in-depth across application, network, and data layers. Access is governed by
                least-privilege principles and monitored for anomalies.
              </p>
            </article>
          </ScrollAnimation>

          {/* Encryption */}
          <ScrollAnimation>
            <article className="service-card p-6">
              <div className="flex items-start gap-3 mb-3">
                <Lock className="w-6 h-6 text-primary" aria-hidden="true" />
                <h2 className="text-xl font-semibold">Data Encryption Methods</h2>
              </div>
              <ul className="list-disc list-inside text-muted-foreground space-y-1">
                <li>Transport encryption: TLS 1.2+ for all in-transit data.</li>
                <li>At-rest encryption with provider-managed keys.</li>
                <li>Key rotation and strict certificate management.</li>
              </ul>
            </article>
          </ScrollAnimation>

          {/* Compliance */}
          <ScrollAnimation>
            <article className="service-card p-6">
              <div className="flex items-start gap-3 mb-3">
                <FileCheck className="w-6 h-6 text-primary" aria-hidden="true" />
                <h2 className="text-xl font-semibold">Compliance Frameworks</h2>
              </div>
              <p className="text-muted-foreground">
                We align with global privacy standards:
              </p>
              <ul className="list-disc list-inside text-muted-foreground space-y-1 mt-2">
                <li>GDPR: data minimization, purpose limitation, rights to access and erasure.</li>
                <li>CCPA: transparent disclosures and opt-out mechanisms.</li>
              </ul>
            </article>
          </ScrollAnimation>

          {/* Infrastructure */}
          <ScrollAnimation>
            <article className="service-card p-6">
              <div className="flex items-start gap-3 mb-3">
                <Server className="w-6 h-6 text-primary" aria-hidden="true" />
                <h2 className="text-xl font-semibold">Infrastructure</h2>
              </div>
              <ul className="list-disc list-inside text-muted-foreground space-y-1">
                <li>Cloud providers with multi-zone redundancy.</li>
                <li>Routine backups and disaster recovery testing.</li>
                <li>Uptime monitoring and incident response procedures.</li>
              </ul>
            </article>
          </ScrollAnimation>

          {/* Customer controls */}
          <ScrollAnimation>
            <article className="service-card p-6">
              <div className="flex items-start gap-3 mb-3">
                <UserCheck className="w-6 h-6 text-primary" aria-hidden="true" />
                <h2 className="text-xl font-semibold">Customer Controls</h2>
              </div>
              <ul className="list-disc list-inside text-muted-foreground space-y-1">
                <li>Self-service data export upon request.</li>
                <li>Deletion requests processed within standard SLAs.</li>
                <li>Role-based access controls for team members.</li>
              </ul>
            </article>
          </ScrollAnimation>

          {/* Security contact */}
          <ScrollAnimation>
            <article className="service-card p-6">
              <div className="flex items-start gap-3 mb-3">
                <MailWarning className="w-6 h-6 text-primary" aria-hidden="true" />
                <h2 className="text-xl font-semibold">Contact for Security Issues</h2>
              </div>
              <p className="text-muted-foreground">
                If you believe you’ve found a security vulnerability, please contact us at{" "}
                <a href="https://mail.google.com/mail/u/0/#inbox" className="no-underline">srithan.gade@gmail.com</a> or{" "}
                <a href="https://mail.google.com/mail/u/0/#inbox" className="no-underline">reeyanthakrar@gmail.com</a> or our published addresses in security.txt.
              </p>
            </article>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
};

export default Security;
