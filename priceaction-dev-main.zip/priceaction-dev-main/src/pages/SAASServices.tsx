import { ArrowLeft, Database, Cloud, Users, CheckCircle, DollarSign, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import ScrollAnimation from "../components/ScrollAnimation";

const SAASServices = () => {
  const benefits = [
    {
      icon: <Cloud className="w-8 h-8" />,
      title: "Scalable Solutions",
      description: "Cloud-based software that grows with your business, handling increased users and data seamlessly."
    },
    {
      icon: <DollarSign className="w-8 h-8" />,
      title: "Recurring Revenue",
      description: "Build sustainable income streams with subscription-based software that customers love to utilize."
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Global Reach",
      description: "Serve customers worldwide with cloud infrastructure that ensures fast, reliable access everywhere."
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: "Business Growth",
      description: "SAAS businesses typically grow 5x faster than traditional software companies with higher valuations."
    }
  ];

  const features = [
    "Subscription management",
    "User authentication & roles",
    "API development",
    "Database design",
    "Payment integration",
    "Analytics dashboard",
    "Mobile responsiveness",
    "Third-party integrations",
    "Automated billing",
    "Customer support tools"
  ];

  const process = [
    {
      step: "1",
      title: "Market Research",
      description: "Analyze your target market, competitors, and identify the specific problem your SAAS will solve."
    },
    {
      step: "2",
      title: "MVP Development",
      description: "Build a minimum viable product with core features to validate your concept and gather user feedback."
    },
    {
      step: "3",
      title: "Scaling & Optimization",
      description: "Expand features, optimize performance, and scale infrastructure based on user growth and feedback."
    },
    {
      step: "4",
      title: "Go-to-Market",
      description: "Launch your SAAS with marketing strategies, customer acquisition, and ongoing support systems."
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="text-center-all space-y-8">
            <ScrollAnimation>
              <Link to="/services" onClick={() => window.scrollTo(0, 0)} className="inline-flex items-center text-primary mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Services
              </Link>
              <h1 className="text-4xl md:text-5xl font-bold">SAAS Development</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Transform your business idea into a profitable Software as a Service platform. 
                We build scalable, subscription-based software that generates recurring revenue.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* What is SAAS */}
      <section className="section-padding">
        <div className="container-width">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation>
              <div className="space-y-6">
                <Database className="w-16 h-16 text-primary" />
                <h2 className="text-3xl font-bold">What is SAAS?</h2>
                <div className="space-y-4">
                  <p className="text-muted-foreground leading-relaxed">
                    <strong className="text-foreground">Software as a Service (SAAS)</strong> is a cloud-based software delivery model 
                    where applications are hosted online and accessed through web browsers or mobile apps via subscription.
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    Instead of selling software once, SAAS businesses generate predictable recurring revenue 
                    while providing continuous value to customers through updates, support, and new features.
                  </p>
                </div>
              </div>
            </ScrollAnimation>
            
            <ScrollAnimation>
              <div className="bg-card rounded-lg p-8 border border-border">
                <h3 className="text-2xl font-semibold mb-6 text-center">SAAS Market Facts</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">Global SAAS market size</span>
                    <span className="text-2xl font-bold text-primary">$195B</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">Annual growth rate</span>
                    <span className="text-2xl font-bold text-primary">18%</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                    <span className="text-muted-foreground">Average customer lifetime value</span>
                    <span className="text-2xl font-bold text-primary">$1,800</span>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Why Build a SAAS Business?</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                SAAS businesses offer unmatched scalability, profitability, and growth potential in today's digital economy.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => (
              <ScrollAnimation key={index}>
                <div className="service-card">
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary flex-shrink-0">
                      {benefit.icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-3">{benefit.title}</h3>
                      <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
                    </div>
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Development Process */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Our SAAS Development Process</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                From concept to launch, we guide you through every step of building a successful SAAS business.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <ScrollAnimation key={index}>
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto text-xl font-bold">
                    {step.step}
                  </div>
                  <h3 className="text-xl font-semibold">{step.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{step.description}</p>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Features & Pricing */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation>
              <div className="space-y-6">
                <h2 className="text-3xl md:text-4xl font-bold">What We Build</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Our SAAS development includes all the essential features needed to run a successful 
                  subscription-based software business.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </ScrollAnimation>
            
            <ScrollAnimation>
              <div className="bg-card rounded-lg p-8 border border-border">
                <h3 className="text-2xl font-semibold mb-6 text-center">SAAS Development Pricing</h3>
                <div className="text-center space-y-6">
                  <Database className="w-16 h-16 text-primary mx-auto" />
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                      <span className="text-muted-foreground">Basic SAAS Platform</span>
                      <span className="text-xl font-bold text-primary">$200</span>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                      <span className="text-muted-foreground">Advanced Features</span>
                      <span className="text-xl font-bold text-primary">$300</span>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                      <span className="text-muted-foreground">Enterprise Solution</span>
                      <span className="text-xl font-bold text-primary">$400</span>
                    </div>
                  </div>
                  <p className="text-muted-foreground text-sm">
                    Pricing varies based on complexity, features, and customization requirements.
                  </p>
                  <div className="mt-6">
                    <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                      Contact Us
                    </Link>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-8">
              <h2 className="text-3xl md:text-4xl font-bold">Ready to Build Your SAAS?</h2>
              <p className="text-lg opacity-90 max-w-2xl mx-auto">
                Transform your business idea into a profitable subscription-based software platform that generates recurring revenue.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="bg-primary-foreground text-primary px-8 py-3 rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                  Start Your SAAS Journey
                </Link>
                <Link to="/services" onClick={() => window.scrollTo(0, 0)} className="border border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary px-8 py-3 rounded-lg font-semibold transition-all duration-300">
                  View All Services
                </Link>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
};

export default SAASServices;