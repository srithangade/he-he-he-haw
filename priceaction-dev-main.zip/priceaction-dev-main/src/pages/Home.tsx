import { Link } from "react-router-dom";
import { ArrowRight, Zap, Bot, Smartphone, TrendingUp, Code, Megaphone, Palette } from "lucide-react";
import ScrollAnimation from "../components/ScrollAnimation";
import HeroSection3D from "../components/HeroSection3D";

const Home = () => {
  const services = [{
    icon: <Code className="w-8 h-8" />,
    title: "Website & Mobile Apps",
    description: "Custom digital solutions that drive business growth."
  }, {
    icon: <Bot className="w-8 h-8" />,
    title: "AI Agents",
    description: "24/7 automated customer service that never sleeps."
  }, {
    icon: <Smartphone className="w-8 h-8" />,
    title: "AI Chatbots",
    description: "Intelligent conversational interfaces for your website."
  }, {
    icon: <TrendingUp className="w-8 h-8" />,
    title: "SaaS",
    description: "Scalable software platforms built for your business needs."
  }];

  return <div className="min-h-screen">
      {/* Hero Section with 3D Background */}
      <HeroSection3D />

      {/* Services Preview */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-12 md:mb-16 px-4">
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold">What We Do</h2>
              <p className="max-w-2xl mx-auto text-gray-500 text-sm sm:text-base leading-relaxed">We specialize in helping individuals and small businesses scale with modern tech solutions. Our offerings include custom website and mobile app development, AI-powered call agents, intelligent chatbots, and tailored SaaS platforms. Every service is designed to be affordable, scalable, and efficient, making advanced AI tools accessible to all. We help integrate these technologies seamlessly into your business to boost growth, automation, and long-term success.</p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 px-4">
            {services.map((service, index) => <ScrollAnimation key={index}>
                <div className="service-card text-center-all p-6">
                  <div className="w-14 h-14 md:w-16 md:h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 text-primary">
                    {service.icon}
                  </div>
                  <h3 className="text-lg md:text-xl font-semibold mb-3">{service.title}</h3>
                  <p className="text-muted-foreground leading-relaxed text-sm">{service.description}</p>
                </div>
              </ScrollAnimation>)}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-center px-4">
            <ScrollAnimation>
              <div className="space-y-6 lg:ml-8">
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold">
                  Why Businesses Choose PriceAction
                </h2>
                <div className="space-y-4 md:space-y-6">
                  <div className="flex items-start space-x-3 md:space-x-4">
                    <div className="w-8 h-8 md:w-10 md:h-10 bg-primary rounded-full flex items-center justify-center mt-1 flex-shrink-0">
                      <Zap className="w-4 h-4 md:w-5 md:h-5 text-primary-foreground" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-sm md:text-base">Lightning-Fast Implementation</h3>
                      <p className="text-xs md:text-sm text-muted-foreground">Deploy AI solutions in days, not months.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 md:space-x-4">
                    <div className="w-8 h-8 md:w-10 md:h-10 bg-primary rounded-full flex items-center justify-center mt-1 flex-shrink-0">
                      <TrendingUp className="w-4 h-4 md:w-5 md:h-5 text-primary-foreground" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-sm md:text-base">Proven ROI Results</h3>
                      <p className="text-xs md:text-sm text-muted-foreground">Average 300% increase in operational efficiency.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 md:space-x-4">
                    <div className="w-8 h-8 md:w-10 md:h-10 bg-primary rounded-full flex items-center justify-center mt-1 flex-shrink-0">
                      <Bot className="w-4 h-4 md:w-5 md:h-5 text-primary-foreground" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-sm md:text-base">24/7 AI Support</h3>
                      <p className="text-xs md:text-sm text-muted-foreground">Round-the-clock automation that works while you sleep.</p>
                    </div>
                  </div>
                </div>
                <Link to="/about" onClick={() => window.scrollTo(0, 0)} className="hero-button inline-flex items-center min-h-[44px] px-4 py-3 text-sm md:text-base">
                  Learn Our Story
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </div>
            </ScrollAnimation>
            
            <ScrollAnimation>
              <div className="bg-card rounded-lg p-6 md:p-8 shadow-elegant">
                <div className="text-center-all space-y-4 md:space-y-6">
                  <h3 className="text-xl md:text-2xl font-semibold">Ready to Transform Your Business?</h3>
                  <p className="text-muted-foreground text-sm md:text-base">
                    Join hundreds of entrepreneurs who have revolutionized their operations with our AI solutions.
                  </p>
                  <div className="grid grid-cols-2 gap-4 text-center-all">
                    <div className="space-y-2">
                      <div className="text-xl md:text-2xl font-bold text-primary">10+</div>
                      <div className="text-xs md:text-sm text-muted-foreground">Projects Completed</div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-xl md:text-2xl font-bold text-primary">100%</div>
                      <div className="text-xs md:text-sm text-muted-foreground">Client Satisfaction</div>
                    </div>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Capabilities Section */}
      <section className="section-padding bg-background">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Our Development Capabilities</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Comprehensive technical expertise across modern technologies and frameworks 
                to deliver cutting-edge solutions.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: "Frontend Development",
                skills: ["React", "Vue.js", "Angular", "Next.js", "TypeScript", "Tailwind CSS"]
              },
              {
                title: "Backend Development",
                skills: ["Node.js", "Python", "PostgreSQL", "MongoDB", "GraphQL", "REST APIs"]
              },
              {
                title: "AI & Machine Learning",
                skills: ["OpenAI", "TensorFlow", "PyTorch", "NLP", "Computer Vision", "Deep Learning"]
              },
              {
                title: "Cloud & DevOps",
                skills: ["AWS", "Google Cloud", "Docker", "Kubernetes", "CI/CD", "Serverless"]
              }
            ].map((category, index) => (
              <ScrollAnimation key={index}>
                <div className="bg-card rounded-lg p-6 border border-border">
                  <h3 className="text-lg font-semibold mb-4">{category.title}</h3>
                  <div className="space-y-2">
                    {category.skills.map((skill, skillIndex) => (
                      <div key={skillIndex} className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                        <span className="text-sm text-muted-foreground">{skill}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>
      
    </div>;
};

export default Home;