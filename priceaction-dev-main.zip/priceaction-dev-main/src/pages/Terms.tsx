import { useEffect } from "react";

const Terms = () => {
  useEffect(() => {
    document.title = "Terms of Service - PriceAction";
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 'Terms of Service for PriceAction - Our terms and conditions for using our AI automation and digital services.');
    }
  }, []);

  return (
    <>
      <div className="container-width section-padding">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-center mb-8">Terms of Service</h1>
          
          <div className="prose prose-lg max-w-none space-y-8">
            <section>
              <p className="text-muted-foreground mb-8">
                Last updated: January 2025
              </p>
              
              <p>
                Welcome to PriceAction. These Terms of Service ("Terms") govern your use of our website 
                and services. By accessing or using our services, you agree to be bound by these Terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Acceptance of Terms</h2>
              <p className="mb-6">
                By accessing and using PriceAction's services, you accept and agree to be bound by the 
                terms and provision of this agreement. If you do not agree to abide by the above, 
                please do not use this service.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Description of Service</h2>
              <p className="mb-4">
                PriceAction provides AI automation, digital solutions, and technology consulting services including:
              </p>
              <ul className="list-disc list-inside space-y-2 mb-6">
                <li>AI chatbot development and implementation</li>
                <li>AI call agent systems</li>
                <li>Website development and design</li>
                <li>SaaS application development</li>
                <li>Digital marketing and automation solutions</li>
                <li>Technology consulting services</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">User Responsibilities</h2>
              <p className="mb-4">As a user of our services, you agree to:</p>
              <ul className="list-disc list-inside space-y-2 mb-6">
                <li>Provide accurate and complete information</li>
                <li>Maintain the security of your account credentials</li>
                <li>Use our services in compliance with applicable laws</li>
                <li>Not engage in any harmful or malicious activities</li>
                <li>Respect intellectual property rights</li>
                <li>Not attempt to reverse engineer our solutions</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Service Availability</h2>
              <p className="mb-6">
                We strive to maintain high service availability, but we do not guarantee uninterrupted service. 
                We may perform maintenance, updates, or experience technical issues that could temporarily 
                affect service availability.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Payment Terms</h2>
              <p className="mb-4">For paid services:</p>
              <ul className="list-disc list-inside space-y-2 mb-6">
                <li>Payment is due according to the agreed schedule</li>
                <li>All fees are non-refundable unless otherwise stated</li>
                <li>Late payments may result in service suspension</li>
                <li>Price changes will be communicated in advance</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Intellectual Property</h2>
              <p className="mb-6">
                All content, features, and functionality of our services are owned by PriceAction and are 
                protected by copyright, trademark, and other intellectual property laws. You may not copy, 
                modify, distribute, or create derivative works without our written consent.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Data and Privacy</h2>
              <p className="mb-6">
                Your privacy is important to us. Please review our Privacy Policy to understand how we 
                collect, use, and protect your information. By using our services, you consent to our 
                data practices as described in the Privacy Policy.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Limitation of Liability</h2>
              <p className="mb-6">
                To the maximum extent permitted by law, PriceAction shall not be liable for any indirect, 
                incidental, special, consequential, or punitive damages, including but not limited to loss 
                of profits, data, or other intangible losses resulting from your use of our services.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Termination</h2>
              <p className="mb-6">
                We may terminate or suspend your access to our services at any time, with or without cause, 
                and with or without notice. Upon termination, your right to use our services will cease immediately.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Dispute Resolution</h2>
              <p className="mb-6">
                Any disputes arising from these Terms or your use of our services shall be resolved through 
                binding arbitration in accordance with applicable laws, rather than in court.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Changes to Terms</h2>
              <p className="mb-6">
                We reserve the right to modify these Terms at any time. We will notify users of significant 
                changes via email or through our website. Continued use of our services constitutes acceptance 
                of the revised Terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Governing Law</h2>
              <p className="mb-6">
                These Terms shall be governed by and construed in accordance with the laws of the jurisdiction 
                in which PriceAction operates, without regard to conflict of law principles.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">Contact Information</h2>
              <p className="mb-4">
                If you have any questions about these Terms of Service, please contact us:
              </p>
              <div className="space-y-2">
                <p>
                  Email:{" "}
                  <a
                    href="https://mail.google.com/mail/u/0/#inbox"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="no-underline"
                  >
                    srithan.gade@gmail.com
                  </a>{" "}
                  or{" "}
                  <a
                    href="https://mail.google.com/mail/u/0/#inbox"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="no-underline"
                  >
                    reeyanthakrar@gmail.com
                  </a>
                </p>
                <p>
                  Phone:{" "}
                  <a href="tel:+18563286178" className="no-underline">
                    1 (856) - 328 - 6178
                  </a>{" "}
                  or{" "}
                  <a href="tel:+16098289420" className="no-underline">
                    1 (609) - 828 - 9420
                  </a>
                </p>
              </div>
            </section>
          </div>
        </div>
      </div>
    </>
  );
};

export default Terms;