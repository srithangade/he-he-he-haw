import { ArrowLeft, Code, Smartphone, CheckCircle, DollarSign } from "lucide-react";
import { Link } from "react-router-dom";
import ScrollAnimation from "../components/ScrollAnimation";

const WebsiteServices = () => {
  const websiteServices = [
    {
      type: "Landing Page",
      price: "100",
      description: "Single page websites perfect for showcasing your business or product.",
      features: ["Responsive Design", "SEO Optimized", "Fast Loading", "Contact Form"],
      status: "Available"
    },
    {
      type: "Single-Page Website",
      price: "200-300",
      description: "Professional single-page websites with multiple sections and enhanced functionality.",
      features: ["Custom Design", "SEO Optimization", "Social Media Integration", "Analytics Setup"],
      status: "Available"
    },
    {
      type: "Multipage Website",
      price: "300-800",
      description: "Comprehensive websites with multiple pages and advanced features.",
      features: ["Multiple Pages", "CMS Integration", "E-commerce Ready", "Blog Functionality", "Advanced SEO"],
      status: "Available"
    },
    {
      type: "3D Website",
      price: "500-1000",
      description: "Cutting-edge websites with 3D elements and interactive experiences.",
      features: ["3D Graphics", "Interactive Elements", "Premium Animations", "Unique User Experience"],
      status: "Available"
    },
    {
      type: "Custom Solutions",
      price: "Price Varies",
      description: "Fully customized websites tailored to your specific wants and needs.",
      features: ["Unlimited Customization", "Advanced Functionality", "Custom Integrations", "Ongoing Support"],
      status: "Available"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="text-center-all space-y-8">
            <ScrollAnimation>
              <Link to="/services" onClick={() => window.scrollTo(0, 0)} className="inline-flex items-center text-primary mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Services
              </Link>
              <h1 className="text-4xl md:text-5xl font-bold">Website & Mobile App Creation</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Professional website development services to establish your digital presence and drive business growth.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Website Services */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <Code className="w-16 h-16 text-primary mx-auto" />
              <h2 className="text-3xl md:text-4xl font-bold">Website Development Services</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                From simple landing pages to complex 3D experiences, we create websites that convert visitors into customers.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {websiteServices.slice(0, 2).map((service, index) => (
              <ScrollAnimation key={index}>
                <div className="service-card relative">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <h3 className="text-2xl font-semibold mb-2">{service.type}</h3>
                      <div className="flex items-center space-x-1 text-primary">
                        <DollarSign className="w-5 h-5" />
                        <span className="text-xl font-bold">{service.price}</span>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-muted-foreground leading-relaxed mb-6">
                    {service.description}
                  </p>

                  <div className="space-y-3 mb-6">
                    <h4 className="font-semibold text-sm uppercase tracking-wide">Features Included</h4>
                    <ul className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                          <span className="text-sm text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="inline-flex items-center justify-center w-full px-4 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                    Contact Us
                  </Link>
                </div>
              </ScrollAnimation>
            ))}
          </div>

          {/* Second Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
            {websiteServices.slice(2, 4).map((service, index) => (
              <ScrollAnimation key={index + 2}>
                <div className="service-card relative">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <h3 className="text-2xl font-semibold mb-2">{service.type}</h3>
                      <div className="flex items-center space-x-1 text-primary">
                        <DollarSign className="w-5 h-5" />
                        <span className="text-xl font-bold">{service.price}</span>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-muted-foreground leading-relaxed mb-6">
                    {service.description}
                  </p>

                  <div className="space-y-3 mb-6">
                    <h4 className="font-semibold text-sm uppercase tracking-wide">Features Included</h4>
                    <ul className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                          <span className="text-sm text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="inline-flex items-center justify-center w-full px-4 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                    Contact Us
                  </Link>
                </div>
              </ScrollAnimation>
            ))}
          </div>

          {/* Custom Solutions - Centered */}
          <div className="flex justify-center mt-8">
            <div className="max-w-lg">
              <ScrollAnimation>
                <div className="service-card relative">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <h3 className="text-2xl font-semibold mb-2">{websiteServices[4].type}</h3>
                      <div className="flex items-center space-x-1 text-primary">
                        <DollarSign className="w-5 h-5" />
                        <span className="text-xl font-bold">{websiteServices[4].price}</span>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-muted-foreground leading-relaxed mb-6">
                    {websiteServices[4].description}
                  </p>

                  <div className="space-y-3 mb-6">
                    <h4 className="font-semibold text-sm uppercase tracking-wide">Features Included</h4>
                    <ul className="space-y-2">
                      {websiteServices[4].features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                          <span className="text-sm text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="inline-flex items-center justify-center w-full px-4 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                    Contact Us
                  </Link>
                </div>
              </ScrollAnimation>
            </div>
          </div>
        </div>
      </section>

      {/* Website Edits Policy */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="bg-card rounded-lg p-8 border border-border">
              <h3 className="text-2xl font-semibold mb-4 text-center">Website Edit Policy</h3>
              <div className="text-center space-y-4">
                <p className="text-lg text-muted-foreground">
                  After booking any website creation service with us:
                </p>
                <div className="space-y-2">
                  <p className="text-primary font-semibold">
                    ✓ First 3 edits are completely FREE
                  </p>
                  <p className="text-muted-foreground">
                    Additional edits: $10 per edit.
                  </p>
                  <div className="mt-6">
                    <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                      Contact Us
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Mobile App Section */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-8">
              <Smartphone className="w-16 h-16 text-primary mx-auto" />
              <h2 className="text-3xl md:text-4xl font-bold">Mobile App Creation</h2>
              <div className="bg-card rounded-lg p-12 border border-border max-w-2xl mx-auto">
                <div className="space-y-4">
                  <div className="inline-block bg-primary/10 px-4 py-2 rounded-full text-sm font-medium text-primary">
                    Coming Soon
                  </div>
                  <h3 className="text-xl font-semibold">Native & Cross-Platform Apps</h3>
                  <p className="text-muted-foreground">
                    We're preparing to launch our mobile app development services. 
                    Stay tuned for iOS and Android app creation with the same quality and attention to detail as our websites.
                  </p>
                </div>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-8">
              <h2 className="text-3xl md:text-4xl font-bold">Ready to Build Your Website?</h2>
              <p className="text-lg opacity-90 max-w-2xl mx-auto">
                Let's create a website that perfectly represents your brand and drives results for your business.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="bg-primary-foreground text-primary px-8 py-3 rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                  Start Your Project
                </Link>
                <Link to="/services" onClick={() => window.scrollTo(0, 0)} className="border border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary px-8 py-3 rounded-lg font-semibold transition-all duration-300">
                  View All Services
                </Link>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
};

export default WebsiteServices;