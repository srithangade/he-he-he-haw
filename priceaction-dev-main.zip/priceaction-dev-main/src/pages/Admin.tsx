import { useState, useEffect } from "react";
import { Mail, Clock, User, MessageSquare, CheckCircle, AlertCircle, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { VisitorTracker } from "@/components/VisitorTracker";
interface ContactMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  status: 'new' | 'read' | 'responded';
  created_at: string;
  updated_at: string;
}
const Admin = () => {
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const {
    toast
  } = useToast();
  const ADMIN_PASSWORD = "PriceAction4321"; // Change this to your desired password

  useEffect(() => {
    // Check if already authenticated from localStorage
    const stored = localStorage.getItem('adminAuthenticated');
    if (stored === 'true') {
      setIsAuthenticated(true);
      fetchMessages();
    } else {
      setLoading(false);
    }
  }, []);
  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      localStorage.setItem('adminAuthenticated', 'true');
      setLoading(true);
      fetchMessages();
    } else {
      toast({
        title: "Error",
        description: "Incorrect password.",
        variant: "destructive"
      });
    }
  };
  const fetchMessages = async () => {
    try {
      const {
        data,
        error
      } = await supabase.from('contact_messages').select('*').order('created_at', {
        ascending: false
      });
      if (error) {
        console.error('Error fetching messages:', error);
        toast({
          title: "Error",
          description: "Failed to load messages. Please try again.",
          variant: "destructive"
        });
      } else {
        setMessages((data || []) as ContactMessage[]);
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const updateMessageStatus = async (messageId: string, newStatus: 'new' | 'read' | 'responded') => {
    try {
      const {
        error
      } = await supabase.from('contact_messages').update({
        status: newStatus
      }).eq('id', messageId);
      if (error) {
        throw error;
      }
      setMessages(prev => prev.map(msg => msg.id === messageId ? {
        ...msg,
        status: newStatus
      } : msg));
      toast({
        title: "Status Updated",
        description: `Message marked as ${newStatus}.`
      });
    } catch (error) {
      console.error('Error updating status:', error);
      toast({
        title: "Error",
        description: "Failed to update message status.",
        variant: "destructive"
      });
    }
  };
  const deleteMessage = async (messageId: string) => {
    if (!confirm('Are you sure you want to delete this message? This action cannot be undone.')) {
      return;
    }
    try {
      const {
        error
      } = await supabase.from('contact_messages').delete().eq('id', messageId);
      if (error) {
        throw error;
      }
      setMessages(prev => prev.filter(msg => msg.id !== messageId));
      toast({
        title: "Message Deleted",
        description: "The message has been successfully deleted."
      });
    } catch (error) {
      console.error('Error deleting message:', error);
      toast({
        title: "Error",
        description: "Failed to delete message.",
        variant: "destructive"
      });
    }
  };
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'new':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'read':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'responded':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      default:
        return <AlertCircle className="w-4 h-4 text-gray-500" />;
    }
  };
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new':
        return 'text-red-600 bg-red-50';
      case 'read':
        return 'text-yellow-600 bg-yellow-50';
      case 'responded':
        return 'text-green-600 bg-green-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };
  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading messages...</p>
        </div>
      </div>;
  }
  if (!isAuthenticated) {
    return <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md p-6">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold">Admin Access</h1>
            <p className="text-muted-foreground">Enter password to continue</p>
          </div>
          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <Input type="password" placeholder="Enter admin password" value={password} onChange={e => setPassword(e.target.value)} required />
            <Button type="submit" className="w-full">
              Login
            </Button>
          </form>
        </Card>
      </div>;
  }
  return <div className="min-h-screen bg-background">
      <div className="container-width py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Contact Messages - Admin</h1>
          <p className="text-muted-foreground">Manage and respond to contact form submissions.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-card p-6 rounded-lg border">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-red-500" />
              <h3 className="font-semibold">New Messages</h3>
            </div>
            <p className="text-2xl font-bold mt-2">
              {messages.filter(m => m.status === 'new').length}
            </p>
          </div>
          
          <div className="bg-card p-6 rounded-lg border">
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-yellow-500" />
              <h3 className="font-semibold">Read</h3>
            </div>
            <p className="text-2xl font-bold mt-2">
              {messages.filter(m => m.status === 'read').length}
            </p>
          </div>
          
          <div className="bg-card p-6 rounded-lg border">
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <h3 className="font-semibold">Responded</h3>
            </div>
            <p className="text-2xl font-bold mt-2">
              {messages.filter(m => m.status === 'responded').length}
            </p>
          </div>
          
          <VisitorTracker />
        </div>

        <div className="bg-card rounded-lg border">
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-4">All Messages</h2>
            {messages.length === 0 ? <div className="text-center py-12">
                <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No messages yet</p>
              </div> : <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Status</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {messages.map(message => <TableRow key={message.id}>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          {getStatusIcon(message.status)}
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(message.status)}`}>
                            {message.status}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{message.name}</TableCell>
                      <TableCell>
                        <a href={`mailto:${message.email}`} className="text-primary">
                          {message.email}
                        </a>
                      </TableCell>
                      <TableCell className="max-w-xs">
                        <p className="truncate">{message.message}</p>
                      </TableCell>
                      <TableCell>
                        {new Date(message.created_at).toLocaleDateString()}
                      </TableCell>
                       <TableCell>
                         <div className="flex space-x-2">
                           {message.status === 'new' && <Button size="sm" variant="outline" onClick={() => updateMessageStatus(message.id, 'read')}>
                               Mark Read
                             </Button>}
                           {message.status === 'read' && <Button size="sm" variant="outline" onClick={() => updateMessageStatus(message.id, 'responded')}>
                               Mark Responded
                             </Button>}
                           <Button size="sm" variant="outline" onClick={() => setSelectedMessage(message)}>
                             View
                           </Button>
                           <Button size="sm" variant="destructive" onClick={() => deleteMessage(message.id)}>
                             <Trash2 className="w-4 h-4" />
                           </Button>
                         </div>
                       </TableCell>
                    </TableRow>)}
                </TableBody>
              </Table>}
          </div>
        </div>

        {/* Message Detail Modal */}
        {selectedMessage && <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-card rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-xl font-semibold">Message Details</h3>
                  <Button variant="outline" size="sm" onClick={() => setSelectedMessage(null)}>
                    Close
                  </Button>
                </div>
                
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Name</label>
                      <p className="font-medium">{selectedMessage.name}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Email</label>
                      <p className="font-medium">
                        <a href={`mailto:${selectedMessage.email}`} className="text-primary">
                          {selectedMessage.email}
                        </a>
                      </p>
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Status</label>
                    <div className="flex items-center space-x-2 mt-1">
                      {getStatusIcon(selectedMessage.status)}
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(selectedMessage.status)}`}>
                        {selectedMessage.status}
                      </span>
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Date Submitted</label>
                    <p className="font-medium">
                      {new Date(selectedMessage.created_at).toLocaleString()}
                    </p>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Message</label>
                    <div className="mt-2 p-4 bg-secondary rounded-lg">
                      <p className="whitespace-pre-wrap">{selectedMessage.message}</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-2 mt-6">
                  {selectedMessage.status === 'new' && <Button onClick={() => {
                updateMessageStatus(selectedMessage.id, 'read');
                setSelectedMessage({
                  ...selectedMessage,
                  status: 'read'
                });
              }}>
                      Mark as Read
                    </Button>}
                  {selectedMessage.status === 'read' && <Button onClick={() => {
                updateMessageStatus(selectedMessage.id, 'responded');
                setSelectedMessage({
                  ...selectedMessage,
                  status: 'responded'
                });
              }}>
                      Mark as Responded
                    </Button>}
                  <Button variant="outline" asChild>
                    <a href={`mailto:${selectedMessage.email}?subject=Re: Your message&body=Hi ${selectedMessage.name},%0A%0AThank you for your message:%0A%0A"${selectedMessage.message}"%0A%0A`}>
                      Reply via Email
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </div>}
      </div>
    </div>;
};
export default Admin;