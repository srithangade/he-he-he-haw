import { Users, Target, Eye, Heart } from "lucide-react";
import ScrollAnimation from "../components/ScrollAnimation";
const About = () => {
  const values = [{
    icon: <Target className="w-8 h-8" />,
    title: "Innovation First",
    description: "We leverage cutting-edge AI technology to solve real business problems."
  }, {
    icon: <Users className="w-8 h-8" />,
    title: "Client Success",
    description: "Your growth is our priority. We measure success by your achievements."
  }, {
    icon: <Eye className="w-8 h-8" />,
    title: "Transparency",
    description: "Clear communication and honest partnerships in everything we do."
  }, {
    icon: <Heart className="w-8 h-8" />,
    title: "Integrity",
    description: "Building trust through reliable solutions and ethical business practices."
  }];
  return <div className="min-h-screen">
      {/* Hero Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="text-center-all space-y-8">
            <ScrollAnimation>
              <h1 className="text-4xl md:text-5xl font-bold">About PriceAction</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                The inspiring story of two ambitious high school entrepreneurs who transformed their vision of 
                business automation and artificial intelligence into a revolutionary mission to create sustainable 
                generational wealth through innovative technology solutions that empower businesses worldwide.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="section-padding">
        <div className="container-width">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation>
              <div className="space-y-6 text-center-all">
                <h2 className="text-3xl md:text-4xl font-bold">Our Story</h2>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>PriceAction was born from the minds of two young entrepreneurs who knew deep down that the traditional path—school, jobs, routine—wasn’t the true route to success. We believed in building, creating, and empowering. With a passion for technology and a hunger for something greater, we saw AI not just as a tool, but as a movement that could reshape the way people live and work. Driven by the idea of generational wealth and lifting others beyond the average, we set out to build a company that wasn’t just profitable, but purposeful. PriceAction was created to give individuals and small businesses access to the kind of innovation that’s usually reserved for major corporations. By offering affordable, high-impact AI services—like chatbots, virtual agents, apps, and SaaS platforms—we’re helping others grow, automate, and rise. This isn’t just a company. It’s a movement. And it’s only the beginning.</p>
                  
                  
                </div>
              </div>
            </ScrollAnimation>
            
            <ScrollAnimation>
              <div className="bg-card rounded-lg p-8 shadow-elegant">
                <div className="text-center-all space-y-6">
                  <h3 className="text-2xl font-semibold">From Vision to Reality</h3>
                  <div className="grid grid-cols-1 gap-6">
                    <div className="space-y-2">
                      <div className="text-3xl font-bold text-primary">2025</div>
                      <div className="text-sm">Founded by two high school entrepreneurs.</div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-3xl font-bold text-primary">10+</div>
                      <div className="text-sm">Businesses transformed.</div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-3xl font-bold text-primary">$1k+</div>
                      <div className="text-sm">In client revenue generated.</div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-3xl font-bold text-primary">24/7</div>
                      <div className="text-sm">AI automation working for clients.</div>
                    </div>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-8">
              <h2 className="text-3xl md:text-4xl font-bold">Our Mission</h2>
              <div className="max-w-4xl mx-auto space-y-6">
                <p className="text-lg leading-relaxed">At PriceAction, our mission is to democratize access to advanced AI and digital solutions, empowering individuals and small businesses to grow, automate, and thrive. We are committed to helping our clients build wealth, break limits, and rise above standards by making innovation simple, affordable, and accessible to all.</p>
                
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Vision */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-8">
              <h2 className="text-3xl md:text-4xl font-bold">Our Vision</h2>
              <div className="max-w-4xl mx-auto space-y-6">
                <p className="text-lg leading-relaxed">Our vision at PriceAction is to lead a global shift toward accessible innovation, where every individual and small business—regardless of background or budget—has the tools to build, scale, and succeed through the power of AI. We aim to create a future where technology isn’t just for the elite, but a universal resource for generational growth, freedom, and legacy-building.</p>
                
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Values */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Our Values</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                The principles that guide everything we do and define who we are as a company.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => <ScrollAnimation key={index}>
                <div className="service-card text-center-all h-full">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 text-primary">
                    {value.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{value.title}</h3>
                  <p className="text-muted-foreground leading-relaxed text-sm">{value.description}</p>
                </div>
              </ScrollAnimation>)}
          </div>
        </div>
      </section>

      {/* Team Philosophy */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-8">
              <h2 className="text-3xl md:text-4xl font-bold">Building Generational Wealth</h2>
              <div className="max-w-4xl mx-auto space-y-6">
                <p className="text-lg leading-relaxed">
                  At PriceAction, we deeply understand that true, lasting success isn't merely about achieving immediate 
                  profits or short-term financial gains – it's about thoughtfully building sustainable, scalable systems 
                  and intelligent infrastructure that create enduring value, compound growth opportunities, and lasting 
                  wealth that can be passed down and leveraged by future generations to continue building upon the 
                  foundation of success.
                </p>
                
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>;
};
export default About;