import { useState } from "react";
import { Plus, Minus } from "lucide-react";
import { Link } from "react-router-dom";
import ScrollAnimation from "../components/ScrollAnimation";
const FAQs = () => {
  const [openFAQ, setOpenFAQ] = useState<number | null>(0);
  const faqs = [{
    question: "What types of AI automation services do you offer?",
    answer: "We offer comprehensive AI automation solutions including AI chatbots for websites, AI agents for customer service, business process automation, predictive analytics, and custom AI integrations. Our solutions are designed to work 24/7, handling everything from customer inquiries to lead qualification and appointment scheduling."
  }, {
    question: "How much do your services cost?",
    answer: "Our pricing varies based on project scope, complexity, and specific requirements. We offer flexible pricing models including one-time project fees, monthly subscriptions, and revenue-sharing arrangements. Contact us for a free consultation where we'll provide a detailed quote tailored to your needs. Most of our AI automation solutions pay for themselves within 3-6 months through increased efficiency and cost savings."
  }, {
    question: "What technologies and platforms do you utilize?",
    answer: "We utilize cutting-edge technologies including React, Node.js, Python, OpenAI APIs, TensorFlow, AWS, Google Cloud, and MongoDB. For AI solutions, we leverage advanced natural language processing, machine learning algorithms, and the latest AI models. We choose technologies based on your specific requirements to ensure optimal performance, scalability, and reliability."
  }, {
    question: "How long does it take to implement an AI automation solution?",
    answer: "Implementation timelines vary by project complexity. Simple AI chatbots can be deployed within 1-2 weeks, while comprehensive automation systems may take 4-8 weeks. We follow an agile development process with regular updates and milestones. During our initial consultation, we'll provide a detailed timeline with specific deliverables and milestones for your project."
  }, {
    question: "Do you provide ongoing support and maintenance?",
    answer: "Yes, we provide comprehensive ongoing support including system monitoring, performance optimization, feature updates, and technical assistance. Our support packages include 24/7 monitoring, monthly performance reports, and continuous improvements to ensure your AI systems evolve with your business needs. We also provide training for your team to maximize the benefits of your new automation systems."
  }, {
    question: "Can you integrate with our existing business systems?",
    answer: "Absolutely! We specialize in seamless integrations with existing CRM systems, databases, payment processors, email marketing platforms, and other business tools. Our team conducts a thorough analysis of your current tech stack to ensure smooth integration without disrupting your existing workflows. We support integrations with popular platforms like Salesforce, HubSpot, Shopify, and many others."
  }, {
    question: "What makes PriceAction different from other automation companies?",
    answer: "As young entrepreneurs ourselves, we bring fresh perspectives and innovative approaches to business automation. We focus on creating generational wealth through technology, not just quick fixes. Our solutions are designed for scalability and long-term growth. We combine cutting-edge AI technology with deep business understanding to deliver solutions that truly transform operations and drive sustainable growth."
  }, {
    question: "Do you work with businesses of all sizes?",
    answer: "Yes, we work with startups, small businesses, and large enterprises. Our solutions are scalable and can be customized for any business size. Whether you're a solo entrepreneur looking to automate customer service or a large corporation needing enterprise-level AI integration, we have the expertise and flexibility to meet your needs. Our pricing and service models are designed to accommodate businesses at every stage of growth."
  }];
  const toggleFAQ = (index: number) => {
    setOpenFAQ(openFAQ === index ? null : index);
  };
  return <div className="min-h-screen">
      {/* Hero Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="text-center-all space-y-8">
            <ScrollAnimation>
              <h1 className="text-4xl md:text-5xl font-bold">Frequently Asked Questions (FAQs)</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Find answers to common questions about our AI automation services, 
                pricing, implementation process, and how we can help transform your business.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section-padding">
        <div className="container-width">
          <div className="max-w-4xl mx-auto">
            <div className="space-y-4">
              {faqs.map((faq, index) => <ScrollAnimation key={index}>
                  <div className="bg-card border border-border rounded-lg overflow-hidden shadow-elegant">
                    <button onClick={() => toggleFAQ(index)} className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-accent transition-colors duration-300">
                      <h3 className="text-lg font-semibold pr-4">{faq.question}</h3>
                      <div className="flex-shrink-0">
                        {openFAQ === index ? <Minus className="w-5 h-5 text-primary" /> : <Plus className="w-5 h-5 text-primary" />}
                      </div>
                    </button>
                    
                    {openFAQ === index && <div className="px-6 pb-4 animate-fade-in">
                        <div className="border-t border-border pt-4">
                          <p className="text-muted-foreground leading-relaxed">
                            {faq.answer}
                          </p>
                        </div>
                      </div>}
                  </div>
                </ScrollAnimation>)}
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Need More Information?</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Explore our detailed guides and resources for specific topics.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[{
            title: "Getting Started",
            description: "Learn about our onboarding process and how to begin your automation journey.",
            topics: ["Initial Consultation", "Project Planning", "Timeline & Milestones", "Team Introduction"]
          }, {
            title: "Technical Details",
            description: "Understand the technology stack and implementation specifics.",
            topics: ["AI Technologies", "Integration Process", "Security & Compliance", "Performance Metrics"]
          }, {
            title: "Support & Maintenance",
            description: "Information about ongoing support, updates, and optimization.",
            topics: ["24/7 Monitoring", "Regular Updates", "Performance Optimization", "Training & Documentation"]
          }].map((category, index) => <ScrollAnimation key={index}>
                <div className="service-card">
                  <h3 className="text-xl font-semibold mb-3">{category.title}</h3>
                  <p className="text-muted-foreground mb-4 text-sm leading-relaxed">
                    {category.description}
                  </p>
                  <ul className="space-y-2">
                    {category.topics.map((topic, topicIndex) => <li key={topicIndex} className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                        <span className="text-sm text-muted-foreground">{topic}</span>
                      </li>)}
                  </ul>
                </div>
              </ScrollAnimation>)}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="bg-primary text-primary-foreground rounded-lg p-12 text-center-all">
              <div className="max-w-2xl mx-auto space-y-6">
                <h2 className="text-3xl font-bold">Still Have Questions?</h2>
                <p className="text-lg opacity-90">
                  Can't find the answer you're looking for? Our team is here to help. 
                  Reach out for a personalized consultation.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="bg-primary-foreground text-primary px-8 py-4 rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                    Contact Support
                  </Link>
                  <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="border-2 border-primary-foreground text-primary-foreground px-8 py-4 rounded-lg font-semibold hover:bg-primary-foreground hover:text-primary transition-all duration-300">
                    Schedule Call
                  </Link>
                </div>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Quick Stats */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all">
              <h2 className="text-3xl font-bold mb-12">Why Choose PriceAction?</h2>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-primary">24/7</div>
                  <div className="text-muted-foreground">AI Support Available.</div>
                </div>
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-primary">{"<2 days"}</div>
                  <div className="text-muted-foreground">Average Implementation.</div>
                </div>
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-primary">300%</div>
                  <div className="text-muted-foreground">Avg. Efficiency Increase.</div>
                </div>
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-primary">100%</div>
                  <div className="text-muted-foreground">Client Satisfaction Rate.</div>
                </div>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>;
};
export default FAQs;