import { useState } from "react";
import { ExternalLink, Code, Smartphone, Bot, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import ScrollAnimation from "../components/ScrollAnimation";

// Import project images
import ecommerceImage from "../assets/ecommerce-project.jpg";
import restaurantImage from "../assets/restaurant-app.jpg";
import chatbotImage from "../assets/ai-chatbot.jpg";
import saasImage from "../assets/saas-dashboard.jpg";
import healthcareImage from "../assets/healthcare-system.jpg";
import fitnessImage from "../assets/fitness-app.jpg";
import voiceImage from "../assets/voice-assistant.jpg";
import projectMgmtImage from "../assets/project-management.jpg";
import realEstateImage from "../assets/real-estate.jpg";

const Gallery = () => {
  const [activeFilter, setActiveFilter] = useState("all");

  const projects = [
    {
      id: 1,
      title: "E-commerce Platform",
      category: "website",
      description: "Full-stack e-commerce solution with AI-powered recommendations.",
      tech: ["React", "Node.js", "AI/ML"],
      image: ecommerceImage
    },
    {
      id: 2,
      title: "Restaurant Mobile App",
      category: "mobile",
      description: "Food delivery app with real-time tracking and AI chatbot support.",
      tech: ["React Native", "Firebase", "AI Chat"],
      image: restaurantImage
    },
    {
      id: 3,
      title: "AI Customer Service Bot",
      category: "ai",
      description: "Intelligent chatbot handling 90% of customer inquiries automatically.",
      tech: ["OpenAI", "Python", "NLP"],
      image: chatbotImage
    },
    {
      id: 4,
      title: "SAAS Analytics Dashboard",
      category: "saas",
      description: "Real-time business intelligence platform with predictive analytics.",
      tech: ["React", "D3.js", "Machine Learning"],
      image: saasImage
    },
    {
      id: 5,
      title: "Healthcare Management System",
      category: "website",
      description: "Patient management platform with AI-assisted diagnostics.",
      tech: ["Vue.js", "Python", "TensorFlow"],
      image: healthcareImage
    },
    {
      id: 6,
      title: "Fitness Tracking App",
      category: "mobile",
      description: "AI-powered fitness coach with personalized workout recommendations.",
      tech: ["Flutter", "Firebase", "AI/ML"],
      image: fitnessImage
    },
    {
      id: 7,
      title: "Voice Assistant Integration",
      category: "ai",
      description: "Smart office assistant with natural language processing capabilities.",
      tech: ["Python", "Speech API", "NLP"],
      image: voiceImage
    },
    {
      id: 8,
      title: "Project Management Tool",
      category: "saas",
      description: "Collaborative workspace with AI-powered task optimization.",
      tech: ["React", "GraphQL", "AI Optimization"],
      image: projectMgmtImage
    },
    {
      id: 9,
      title: "Real Estate Platform",
      category: "website",
      description: "Property listing site with AI-powered valuation and matching.",
      tech: ["Next.js", "Python", "Computer Vision"],
      image: realEstateImage
    }
  ];

  const filters = [
    { id: "all", label: "All Projects", icon: <TrendingUp className="w-4 h-4" /> },
    { id: "website", label: "Websites", icon: <Code className="w-4 h-4" /> },
    { id: "mobile", label: "Mobile Apps", icon: <Smartphone className="w-4 h-4" /> },
    { id: "ai", label: "AI Solutions", icon: <Bot className="w-4 h-4" /> },
    { id: "saas", label: "SAAS Platforms", icon: <TrendingUp className="w-4 h-4" /> }
  ];

  const filteredProjects = activeFilter === "all" 
    ? projects 
    : projects.filter(project => project.category === activeFilter);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="text-center-all space-y-8">
            <ScrollAnimation>
              <h1 className="text-4xl md:text-5xl font-bold">Project Gallery</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Explore our portfolio of innovative AI-powered solutions, cutting-edge websites, 
                mobile applications, and SAAS platforms that have transformed businesses worldwide.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Filter Navigation */}
      <section className="py-8 bg-background border-b border-border">
        <div className="container-width">
          <ScrollAnimation>
            <div className="flex flex-wrap justify-center gap-4">
              {filters.map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setActiveFilter(filter.id)}
                  className={`flex items-center space-x-2 px-6 py-3 rounded-lg font-medium transition-all duration-300 ${
                    activeFilter === filter.id
                      ? 'bg-primary text-primary-foreground shadow-elegant'
                      : 'bg-card hover:bg-accent border border-border'
                  }`}
                >
                  {filter.icon}
                  <span>{filter.label}</span>
                </button>
              ))}
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="section-padding">
        <div className="container-width">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project, index) => (
              <ScrollAnimation key={project.id}>
                <div className="service-card group cursor-pointer">
                  {/* Project Image */}
                  <div className="relative overflow-hidden rounded-lg mb-6 aspect-video">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-full object-cover"
                      loading="lazy"
                      decoding="async"
                      sizes="(min-width: 1024px) 33vw, (min-width: 768px) 50vw, 100vw"
                    />
                    
                    {/* Hover overlay */}
                    <div className="absolute inset-0 bg-primary/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <div className="text-center-all text-primary-foreground">
                        <ExternalLink className="w-8 h-8 mx-auto mb-2" />
                        <p className="text-sm font-medium">View Details</p>
                      </div>
                    </div>
                  </div>

                  {/* Project Info */}
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                      <p className="text-muted-foreground text-sm leading-relaxed">
                        {project.description}
                      </p>
                    </div>

                    {/* Tech Stack */}
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                        Technologies Utilized
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {project.tech.map((tech, techIndex) => (
                          <span
                            key={techIndex}
                            className="px-3 py-1 bg-secondary text-secondary-foreground rounded-full text-xs font-medium"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Capabilities Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">Our Development Capabilities</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Comprehensive technical expertise across modern technologies and frameworks 
                to deliver cutting-edge solutions.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: "Frontend Development",
                skills: ["React", "Vue.js", "Angular", "Next.js", "TypeScript", "Tailwind CSS"]
              },
              {
                title: "Backend Development",
                skills: ["Node.js", "Python", "PostgreSQL", "MongoDB", "GraphQL", "REST APIs"]
              },
              {
                title: "AI & Machine Learning",
                skills: ["OpenAI", "TensorFlow", "PyTorch", "NLP", "Computer Vision", "Deep Learning"]
              },
              {
                title: "Cloud & DevOps",
                skills: ["AWS", "Google Cloud", "Docker", "Kubernetes", "CI/CD", "Serverless"]
              }
            ].map((category, index) => (
              <ScrollAnimation key={index}>
                <div className="bg-card rounded-lg p-6 border border-border">
                  <h3 className="text-lg font-semibold mb-4">{category.title}</h3>
                  <div className="space-y-2">
                    {category.skills.map((skill, skillIndex) => (
                      <div key={skillIndex} className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                        <span className="text-sm text-muted-foreground">{skill}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-8">
              <h2 className="text-3xl md:text-4xl font-bold">Ready to Build Something Amazing?</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Let's collaborate to create innovative solutions that will transform your business 
                and set you apart from the competition.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Link to="/services" onClick={() => window.scrollTo(0, 0)} className="hero-button">
                  Start Your Project
                </Link>
                <Link to="/gallery" onClick={() => window.scrollTo(0, 0)} className="outline-button">
                  View More Work
                </Link>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>
  );
};

export default Gallery;