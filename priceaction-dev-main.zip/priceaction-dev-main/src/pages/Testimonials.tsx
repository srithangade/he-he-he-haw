import { useState, useEffect } from "react";
import { Star, Quote, ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import ScrollAnimation from "../components/ScrollAnimation";
const Testimonials = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const testimonials = [{
    name: "Sarah Mitchell",
    position: "CEO, TechFlow Solutions",
    image: "/placeholder-avatar.svg",
    rating: 5,
    text: "PriceAction's AI chatbot increased our customer engagement by 400% in just 3 months. Their team's expertise in automation is unmatched. The ROI has been incredible – we've saved over 200 hours of manual customer service work monthly."
  }, {
    name: "Marcus Johnson",
    position: "Founder, GrowthHub Marketing",
    image: "/placeholder-avatar.svg",
    rating: 5,
    text: "The website and mobile app they built for us is absolutely stunning. Our conversion rates have tripled since launch. The attention to detail and user experience design is phenomenal. Best investment we've made for our digital presence."
  }, {
    name: "Sean Kong-Quee",
    position: "Manager, Calle Del Sabor",
    image: "/placeholder-avatar.svg",
    rating: 5,
    text: "Great service. Very speedy delivery of any web product that we have had. You guys have our businesses forward."
  }, {
    name: "David Rodriguez",
    position: "Owner, Elite Consulting",
    image: "/placeholder-avatar.svg",
    rating: 5,
    text: "The SAAS platform they developed for us has revolutionized how we serve our clients. Scalable, robust, and user-friendly. Our monthly recurring revenue has increased by 250% since implementation. Exceptional work!"
  }, {
    name: "Lisa Thompson",
    position: "CMO, Digital Dynamics",
    image: "/placeholder-avatar.svg",
    rating: 5,
    text: "From concept to launch, PriceAction exceeded every expectation. Their AI automation solutions freed up our team to focus on strategy rather than repetitive tasks. The level of innovation and professionalism is outstanding."
  }];
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [testimonials.length]);
  const nextSlide = () => {
    setCurrentSlide(prev => (prev + 1) % testimonials.length);
  };
  const prevSlide = () => {
    setCurrentSlide(prev => (prev - 1 + testimonials.length) % testimonials.length);
  };
  const renderStars = (rating: number) => {
    return Array.from({
      length: 5
    }, (_, i) => <Star key={i} className={`w-5 h-5 ${i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} />);
  };
  return <div className="min-h-screen">
      {/* Hero Section */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <div className="text-center-all space-y-8">
            <ScrollAnimation>
              <h1 className="text-4xl md:text-5xl font-bold">Client Testimonials</h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Discover how PriceAction has transformed businesses across industries 
                with our AI-powered automation solutions and innovative digital strategies.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Featured Testimonial Carousel */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="relative max-w-4xl mx-auto">
              <div className="bg-card rounded-lg p-12 shadow-elegant">
                <div className="text-center-all space-y-6">
                  <Quote className="w-12 h-12 text-primary mx-auto opacity-50" />
                  
                  <div className="space-y-4">
                    <p className="text-lg md:text-xl leading-relaxed italic">
                      "{testimonials[currentSlide].text}"
                    </p>
                    
                    <div className="flex justify-center space-x-1">
                      {renderStars(testimonials[currentSlide].rating)}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg">{testimonials[currentSlide].name}</h3>
                    <p className="text-muted-foreground">{testimonials[currentSlide].position}</p>
                  </div>
                </div>
              </div>

              {/* Navigation */}
              <button onClick={prevSlide} className="absolute left-4 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-background border border-border rounded-full flex items-center justify-center hover:shadow-hover transition-all duration-300">
                <ChevronLeft className="w-6 h-6" />
              </button>
              
              <button onClick={nextSlide} className="absolute right-4 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-background border border-border rounded-full flex items-center justify-center hover:shadow-hover transition-all duration-300">
                <ChevronRight className="w-6 h-6" />
              </button>

              {/* Dots */}
              <div className="flex justify-center space-x-2 mt-8">
                {testimonials.map((_, index) => <button key={index} onClick={() => setCurrentSlide(index)} className={`w-3 h-3 rounded-full transition-all duration-300 ${index === currentSlide ? 'bg-primary' : 'bg-border'}`} />)}
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* All Testimonials Grid */}
      <section className="section-padding bg-secondary">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl font-bold">What Our Clients Say</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Real feedback from real businesses that have experienced transformational growth 
                through our AI automation solutions.
              </p>
            </div>
          </ScrollAnimation>

          {/* First 3 testimonials */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-8 items-stretch">
            {testimonials.slice(0, 3).map((testimonial, index) => <ScrollAnimation key={index} className="h-full">
                <div className="service-card h-full flex flex-col">
                  <div className="flex justify-center space-x-1 mb-4">
                    {renderStars(testimonial.rating)}
                  </div>
                  
                  <p className="text-muted-foreground leading-relaxed mb-6 italic">
                    "{testimonial.text}"
                  </p>
                  
                  <div className="flex items-center space-x-3 mt-auto">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <span className="font-semibold text-primary">
                        {testimonial.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div>
                      <h3 className="font-semibold">{testimonial.name}</h3>
                      <p className="text-sm text-muted-foreground">{testimonial.position}</p>
                    </div>
                  </div>
                </div>
              </ScrollAnimation>)}
          </div>
          
          {/* Last 2 testimonials centered */}
          <div className="flex justify-center">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl items-stretch">
              {testimonials.slice(3).map((testimonial, index) => <ScrollAnimation key={index + 3} className="h-full">
                  <div className="service-card h-full flex flex-col">
                    <div className="flex justify-center space-x-1 mb-4">
                      {renderStars(testimonial.rating)}
                    </div>
                    
                    <p className="text-muted-foreground leading-relaxed mb-6 italic">
                      "{testimonial.text}"
                    </p>
                    
                    <div className="flex items-center space-x-3 mt-auto">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                        <span className="font-semibold text-primary">
                          {testimonial.name.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                      <div>
                        <h3 className="font-semibold">{testimonial.name}</h3>
                        <p className="text-sm text-muted-foreground">{testimonial.position}</p>
                      </div>
                    </div>
                  </div>
                </ScrollAnimation>)}
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="section-padding">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-12">
              <h2 className="text-3xl md:text-4xl font-bold">Client Success Metrics</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-primary">10+</div>
                  <div className="text-muted-foreground">Projects Completed.</div>
                </div>
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-primary">100%</div>
                  <div className="text-muted-foreground">Client Satisfaction.</div>
                </div>
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-primary">300%</div>
                  <div className="text-muted-foreground">Avg. Efficiency Increase.</div>
                </div>
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-primary">$1k+</div>
                  <div className="text-muted-foreground">Client Revenue Generated.</div>
                </div>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-width">
          <ScrollAnimation>
            <div className="text-center-all space-y-8">
              <h2 className="text-3xl md:text-4xl font-bold">Ready to Join Our Success Stories?</h2>
              <p className="text-lg opacity-90 max-w-2xl mx-auto">
                Transform your business with our proven AI automation solutions and become our next success story.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Link to="/services" onClick={() => window.scrollTo(0, 0)} className="bg-primary-foreground text-primary px-8 py-4 rounded-lg font-semibold hover:scale-105 transition-transform duration-300">
                  Start Your Transformation
                </Link>
                <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="border-2 border-primary-foreground text-primary-foreground px-8 py-4 rounded-lg font-semibold hover:bg-primary-foreground hover:text-primary transition-all duration-300">
                  Schedule Consultation
                </Link>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </div>;
};
export default Testimonials;