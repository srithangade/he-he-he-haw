// Analytics and Consent Mode v2 helpers
// Minimal GA4 + Consent Mode implementation with event utilities

export type ConsentState = {
  necessary: true;
  analytics: boolean;
  marketing: boolean;
};

const CONSENT_KEY = 'cookieConsentV2';

// Ensure dataLayer and gtag exist and set default denied consent
export function initConsentMode() {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const w = window as any;
  w.dataLayer = w.dataLayer || [];
  w.gtag = w.gtag || function () { w.dataLayer.push(arguments); };

  // Default: deny all non-essential until user opts in
  w.gtag('consent', 'default', {
    ad_storage: 'denied',
    ad_user_data: 'denied',
    ad_personalization: 'denied',
    analytics_storage: 'denied',
  });

  // If we have stored preferences, apply them
  try {
    const saved = localStorage.getItem(CONSENT_KEY);
    if (saved) {
      const parsed: ConsentState = JSON.parse(saved);
      applyConsent(parsed);
    }
  } catch (e) {
    // ignore
  }
}

export function applyConsent(consent: ConsentState) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const w = window as any;
  const analyticsGranted = consent.analytics ? 'granted' : 'denied';
  const marketingGranted = consent.marketing ? 'granted' : 'denied';
  w.gtag?.('consent', 'update', {
    analytics_storage: analyticsGranted,
    ad_storage: marketingGranted,
    ad_user_data: marketingGranted,
    ad_personalization: marketingGranted,
  });
}

export function saveConsent(consent: ConsentState) {
  localStorage.setItem(CONSENT_KEY, JSON.stringify(consent));
  applyConsent(consent);
}

// Optionally load GA4 script when provided an ID
export function loadGA(measurementId: string) {
  if (!measurementId) return;
  // Avoid double-loading
  if (document.getElementById('ga4-src')) return;

  const script = document.createElement('script');
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
  script.id = 'ga4-src';
  document.head.appendChild(script);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const w = window as any;
  w.gtag('js', new Date());
  w.gtag('config', measurementId, {
    send_page_view: false, // we'll handle page views manually
    anonymize_ip: true,
  });
}

// Track events (Consent Mode will gate delivery)
export function trackEvent(eventName: string, params: Record<string, any> = {}) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const w = window as any;
  w.gtag?.('event', eventName, params);
  // Also push to dataLayer for GTM setups
  w.dataLayer?.push?.({ event: eventName, ...params });
}

// Global listeners for CTA clicks, chat opens, and form submissions
export function attachGlobalAnalyticsListeners() {
  // CTA clicks via [data-cta]
  document.addEventListener('click', (e) => {
    const target = e.target as HTMLElement | null;
    const el = target?.closest('[data-cta]') as HTMLElement | null;
    if (el) {
      const label = el.getAttribute('data-cta') || el.textContent || 'cta';
      trackEvent('cta_click', {
        cta_label: label.trim(),
        page_path: location.pathname,
      });
    }

    // Chat open via [data-chat-open]
    const chatEl = target?.closest('[data-chat-open]');
    if (chatEl) {
      trackEvent('chat_open', {
        page_path: location.pathname,
      });
    }
  });

  // Form submissions
  document.addEventListener('submit', (e) => {
    const form = e.target as HTMLFormElement;
    const name = form.getAttribute('name') || form.getAttribute('id') || form.getAttribute('aria-label') || 'form';
    trackEvent('form_submit', {
      form_name: name,
      page_path: location.pathname,
    });
  }, true);
}
