// Minimal Web Vitals to GA4/Datalayer bridge
import { onCLS, onINP, onLCP, onFCP, onTTFB, onFID, Metric } from 'web-vitals';

function sendToAnalytics(metric: Metric) {
  const payload = {
    event: 'web_vitals',
    event_category: 'Web Vitals',
    event_label: metric.name,
    value: Math.round(metric.name === 'CLS' ? metric.value * 1000 : metric.value),
    id: metric.id,
  };

  // GA4 via gtag
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  (window as any).gtag?.('event', metric.name, {
    value: payload.value,
    metric_id: metric.id,
    metric_value: metric.value,
    metric_delta: metric.delta,
  });

  // Fallback to dataLayer
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  (window as any).dataLayer?.push?.(payload);
}

export function initWebVitals() {
  onCLS(sendToAnalytics);
  onINP(sendToAnalytics);
  onLCP(sendToAnalytics);
  onFCP(sendToAnalytics);
  onTTFB(sendToAnalytics);
  onFID(sendToAnalytics);
}
