import { useState, useEffect } from "react";
import { Users, Eye } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
interface Visitor {
  user_id: string;
  joined_at: string;
  page: string;
}
interface VisitorTrackerProps {
  className?: string;
}
export const VisitorTracker = ({
  className
}: VisitorTrackerProps) => {
  const [visitors, setVisitors] = useState<Visitor[]>([]);
  const [totalOnline, setTotalOnline] = useState(0);
  useEffect(() => {
    // Create a unique user ID for this session
    const userId = `visitor_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Subscribe to the admin page presence channel
    const channel = supabase.channel('admin_visitors', {
      config: {
        presence: {
          key: userId
        }
      }
    });

    // Track this user's presence
    channel.on('presence', {
      event: 'sync'
    }, () => {
      const state = channel.presenceState();
      const currentVisitors: Visitor[] = [];
      Object.values(state).forEach((presence: any) => {
        presence.forEach((user: any) => {
          currentVisitors.push({
            user_id: user.user_id,
            joined_at: user.joined_at,
            page: user.page
          });
        });
      });
      setVisitors(currentVisitors);
      setTotalOnline(currentVisitors.length);
    }).on('presence', {
      event: 'join'
    }, ({
      key,
      newPresences
    }) => {
      console.log('User joined:', key, newPresences);
    }).on('presence', {
      event: 'leave'
    }, ({
      key,
      leftPresences
    }) => {
      console.log('User left:', key, leftPresences);
    }).subscribe(async status => {
      if (status === 'SUBSCRIBED') {
        // Track this user's presence
        await channel.track({
          user_id: userId,
          joined_at: new Date().toISOString(),
          page: 'admin'
        });
      }
    });

    // Cleanup on unmount
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);
  const formatTime = (timestamp: string) => {
    const now = new Date();
    const joinTime = new Date(timestamp);
    const diffMs = now.getTime() - joinTime.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return joinTime.toLocaleDateString();
  };
  return <Card className={`p-6 ${className}`}>
      <div className="flex items-center space-x-2 mb-4">
        <Eye className="w-5 h-5 text-blue-500" />
        <h3 className="font-semibold">Live Applicants</h3>
      </div>
      
      <div className="flex items-center space-x-2 mb-4">
        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
        <span className="text-2xl font-bold">{totalOnline}</span>
        <span className="text-sm text-muted-foreground">online now</span>
      </div>

      <div className="space-y-2 max-h-40 overflow-y-auto">
        {visitors.length === 0 ? <p className="text-sm text-muted-foreground">No visitors currently</p> : visitors.map(visitor => <div key={visitor.user_id} className="flex items-center justify-between p-2 bg-secondary/50 rounded-lg">
              <div className="flex items-center space-x-2">
                <Users className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-medium">
                  {visitor.user_id.split('_')[1] ? `Visitor ${visitor.user_id.split('_')[1].slice(0, 4)}` : 'Anonymous'}
                </span>
              </div>
              <span className="text-xs text-muted-foreground">
                {formatTime(visitor.joined_at)}
              </span>
            </div>)}
      </div>
    </Card>;
};