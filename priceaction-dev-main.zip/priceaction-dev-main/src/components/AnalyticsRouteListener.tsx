import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { trackEvent } from '@/lib/analytics';

const AnalyticsRouteListener = () => {
  const location = useLocation();

  useEffect(() => {
    // Fire page_view on route change
    trackEvent('page_view', {
      page_location: window.location.href,
      page_path: location.pathname,
      page_title: document.title,
    });
  }, [location.pathname]);

  return null;
};

export default AnalyticsRouteListener;
