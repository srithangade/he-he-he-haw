import { Link } from "react-router-dom";
import { Mail, Phone, MapPin } from "lucide-react";
const Footer = () => {
  const navigation = [{
    name: "Home",
    href: "/"
  }, {
    name: "About Us",
    href: "/about"
  }, {
    name: "Services",
    href: "/services"
  }, {
    name: "Contact",
    href: "/contact"
  }, {
    name: "Testimonials",
    href: "/testimonials"
  }, {
    name: "Gallery",
    href: "/gallery"
  }, {
    name: "FAQs",
    href: "/faqs"
  }];
  return <footer className="bg-primary text-primary-foreground">
      <div className="container-width">
        <div className="section-padding">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center-all md:text-left">
            {/* Company Info */}
            <div className="space-y-4">
              <div className="flex items-center justify-center md:justify-start">
                <span className="font-bold text-xl">PriceAction</span>
              </div>
              <p className="text-sm leading-relaxed opacity-90">
                Empowering businesses with cutting-edge AI automation, digital solutions, and growth strategies. 
                Creating generational wealth through innovative technology.
              </p>
            </div>

            {/* Quick Links */}
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Quick Links</h3>
              <div className="flex flex-col space-y-2">
                {navigation.map(item => <Link key={item.name} to={item.href} onClick={() => window.scrollTo(0, 0)} className="hover:opacity-80 transition-opacity duration-300 text-sm">
                    {item.name}
                  </Link>)}
              </div>
            </div>

            {/* Contact Info */}
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Get In Touch</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-center md:justify-start space-x-2">
                  <Mail size={16} />
                  <div className="text-sm space-x-1">
                    <a href="https://mail.google.com/mail/u/0/#inbox" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
                      srithan.gade@gmail.com
                    </a>
                    <span>or</span>
                    <a href="https://mail.google.com/mail/u/0/#inbox" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
                      reeyanthakrar@gmail.com
                    </a>
                  </div>
                </div>
                <div className="flex items-center justify-center md:justify-start space-x-2">
                  <Phone size={16} />
                  <div className="text-sm space-x-1">
                    <a href="tel:+18563286178" className="hover:opacity-80 transition-opacity">
                      1 (856) - 328 - 6178
                    </a>
                    <span>or</span>
                    <a href="tel:+16098289420" className="hover:opacity-80 transition-opacity">
                      1 (609) - 828 - 9420
                    </a>
                  </div>
                </div>
                <div className="flex items-center justify-center md:justify-start space-x-2">
                  
                  <span className="text-sm">
                </span>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-primary-foreground/20 mt-12 pt-8 text-center-all">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-2 md:space-y-0">
              <p className="text-sm opacity-80">
                © 2025 PriceAction. All rights reserved. Built with innovation and excellence.
              </p>
              <div className="flex space-x-4">
                <Link 
                  to="/privacy" 
                  onClick={() => window.scrollTo(0, 0)}
                  className="text-sm hover:opacity-80 transition-opacity duration-300"
                >
                  Privacy Policy
                </Link>
                <Link 
                  to="/terms" 
                  onClick={() => window.scrollTo(0, 0)}
                  className="text-sm hover:opacity-80 transition-opacity duration-300"
                >
                  Terms of Service
                </Link>
                <Link 
                  to="/security" 
                  onClick={() => window.scrollTo(0, 0)}
                  className="text-sm hover:opacity-80 transition-opacity duration-300"
                >
                  Security & Compliance
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>;
};
export default Footer;