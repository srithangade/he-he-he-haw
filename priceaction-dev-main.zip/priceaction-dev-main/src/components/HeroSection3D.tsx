import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import ScrollAnimation from "./ScrollAnimation";
import { SplineScene } from "./ui/splite";
import { Spotlight } from "./ui/spotlight";
export default function HeroSection3D() {
  return <section className="relative min-h-screen bg-black/[0.96] text-primary-foreground overflow-hidden">
      <Spotlight className="-top-40 left-0 md:left-60 md:-top-20" fill="white" />
      
      <div className="flex flex-col lg:flex-row h-screen">
        {/* Left content */}
        <div className="flex-1 section-padding relative z-10 flex flex-col justify-center min-h-[60vh] lg:min-h-screen">
          <div className="container-width">
            <ScrollAnimation>
              <div className="space-y-4 md:space-y-6">
                <div className="inline-block bg-primary-foreground/10 px-3 py-2 md:px-4 rounded-full text-xs md:text-sm font-medium backdrop-blur-sm">
                  AI Integration is Here
                </div>
                <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-white">
                  PriceAction is the Future.
                </h1>
                <h2 className="text-lg sm:text-xl md:text-2xl font-medium text-white">
                  <em>Why not be part of it?</em>
                </h2>
                <p className="text-sm sm:text-base md:text-lg leading-relaxed max-w-lg text-slate-50">From affordable website and mobile app development to cutting-edge AI agents, intelligent chatbots, and scalable SaaS platforms, PriceAction makes advanced technology accessible. Our mission is clear: to empower others to grow, expand, and thrive in the AI-driven world.</p>
                <div className="flex flex-col sm:flex-row gap-3 md:gap-4 pt-4">
                  <Link to="/contact" onClick={() => window.scrollTo(0, 0)} className="hero-button bg-primary-foreground text-primary hover:scale-105 whitespace-nowrap inline-flex items-center justify-center px-4 py-3 md:px-6 text-sm md:text-base min-h-[44px]">
                    Book a Free Consult
                    <ArrowRight className="ml-2 w-4 h-4 md:w-5 md:h-5" />
                  </Link>
                  <Link to="/services" onClick={() => window.scrollTo(0, 0)} className="hero-button bg-primary-foreground text-primary hover:scale-105 whitespace-nowrap inline-flex items-center justify-center px-4 py-3 md:px-6 text-sm md:text-base min-h-[44px]">
                    Explore Platform
                  </Link>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>

        {/* Right content - 3D Robot */}
        <div className="flex-1 relative min-h-[40vh] lg:min-h-screen">
          <SplineScene scene="https://prod.spline.design/kZDDjO5HuC9GJUM2/scene.splinecode" className="w-full h-full" />
        </div>
      </div>
    </section>;
}