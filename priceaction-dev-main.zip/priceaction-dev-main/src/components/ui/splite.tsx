'use client'

import React, { Suspense, lazy, useMemo } from 'react'
const Spline = lazy(() => import('@splinetool/react-spline'))

interface SplineSceneProps {
  scene: string
  className?: string
}

function isWebGLAvailable() {
  try {
    if (typeof window === 'undefined') return false
    const canvas = document.createElement('canvas')
    const gl =
      (canvas.getContext('webgl2') as WebGL2RenderingContext | null) ||
      (canvas.getContext('webgl') as WebGLRenderingContext | null) ||
      (canvas.getContext('experimental-webgl') as WebGLRenderingContext | null)
    return !!gl
  } catch {
    return false
  }
}

class SplineErrorBoundary extends React.Component<React.PropsWithChildren<{ fallback: React.ReactNode }>, { hasError: boolean }> {
  constructor(props: React.PropsWithChildren<{ fallback: React.ReactNode }>) {
    super(props)
    this.state = { hasError: false }
  }
  static getDerivedStateFromError() {
    return { hasError: true }
  }
  componentDidCatch() {
    // Swallow Spline WebGL errors and show fallback
  }
  render() {
    if (this.state.hasError) return this.props.fallback
    return this.props.children as React.ReactNode
  }
}

export function SplineScene({ scene, className }: SplineSceneProps) {
  const canUseWebGL = useMemo(() => isWebGLAvailable(), [])

  const Fallback = (
    <div className="w-full h-full flex items-center justify-center bg-muted/20">
      <div className="text-center space-y-2">
        <span className="loader" aria-hidden="true" />
        <p className="text-sm text-muted-foreground">3D preview unavailable on this device.</p>
      </div>
    </div>
  )

  if (!canUseWebGL) return Fallback

  return (
    <Suspense
      fallback={
        <div className="w-full h-full flex items-center justify-center">
          <span className="loader"></span>
        </div>
      }
    >
      <SplineErrorBoundary fallback={Fallback}>
        <Spline scene={scene} className={className} />
      </SplineErrorBoundary>
    </Suspense>
  )
}
