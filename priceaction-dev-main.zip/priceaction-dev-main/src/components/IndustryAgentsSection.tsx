import { FC, type ComponentType, type SVGProps } from "react";
import ScrollAnimation from "./ScrollAnimation";
import {
  ShoppingCart,
  Home,
  Stethoscope,
  Megaphone,
  CreditCard,
  Truck,
  GraduationCap,
  Cog,
  BedDouble,
  Scale,
  Palette,
  Landmark,
  ChevronRight,
} from "lucide-react";

interface ServiceItem {
  title: string;
  description: string;
}

interface IndustryItem {
  name: string;
  icon: ComponentType<SVGProps<SVGSVGElement>>;
  emoji: string;
  services: ServiceItem[];
}

const industries: IndustryItem[] = [
  {
    name: "E-Commerce & Retail",
    emoji: "🛍️",
    icon: ShoppingCart,
    services: [
      { title: "Lead Generation Agents", description: "Find potential customers, scrape leads, manage outreach." },
      { title: "Customer Service Chatbots", description: "Handle FAQs, returns, tracking inquiries." },
      { title: "Product Recommendation Agents", description: "Upsell and cross-sell using personalized data." },
      { title: "Inventory Optimization Agents", description: "Forecast demand, suggest restocks." },
      { title: "AI Ad Optimization Agents", description: "Dynamically adjust ad spend across Google/Facebook." },
    ],
  },
  {
    name: "Real Estate",
    emoji: "🏠",
    icon: Home,
    services: [
      { title: "Property Search Agents", description: "Scrape listings & filter for specific client needs." },
      { title: "CRM Automation Agents", description: "Follow up with leads via email/text automatically." },
      { title: "Market Analysis Agents", description: "Predict property value changes & identify hot markets." },
      { title: "Contract Drafting Agents", description: "Pre-fill offers, leases, and agreements." },
      { title: "3D Tour Creation Agents", description: "Turn floor plans into virtual walkthroughs." },
    ],
  },
  {
    name: "Healthcare",
    emoji: "🩺",
    icon: Stethoscope,
    services: [
      { title: "Patient Scheduling Agents", description: "Optimize appointment slots & reminders." },
      { title: "Medical Record Summarization Agents", description: "Extract key info for quick doctor review." },
      { title: "Symptom-Checker Agents", description: "Triage patients before appointments." },
      { title: "Insurance Claim Processing Agents", description: "Auto-validate and submit claims." },
      { title: "Drug Interaction Checkers", description: "Instantly warn about prescription conflicts." },
    ],
  },
  {
    name: "Marketing & Advertising",
    emoji: "📈",
    icon: Megaphone,
    services: [
      { title: "Content Creation Agents", description: "Generate blog posts, ad copy, scripts." },
      { title: "Social Media Growth Agents", description: "Schedule, post, and respond automatically." },
      { title: "SEO Optimization Agents", description: "Analyze rankings and suggest keyword updates." },
      { title: "A/B Testing Agents", description: "Run experiments and adapt campaigns in real time." },
      { title: "Influencer Outreach Agents", description: "Find and contact relevant influencers." },
    ],
  },
  {
    name: "Finance & Banking",
    emoji: "💳",
    icon: CreditCard,
    services: [
      { title: "Fraud Detection Agents", description: "Flag unusual transactions instantly." },
      { title: "Portfolio Optimization Agents", description: "Rebalance based on market changes." },
      { title: "Expense Tracking Agents", description: "Categorize and forecast spending." },
      { title: "Loan Risk Assessment Agents", description: "Analyze applicant data to predict defaults." },
      { title: "Automated Tax Filing Agents", description: "Prepare returns with minimal human input." },
    ],
  },
  {
    name: "Logistics & Supply Chain",
    emoji: "🚚",
    icon: Truck,
    services: [
      { title: "Route Optimization Agents", description: "Reduce fuel costs and delivery times." },
      { title: "Demand Forecasting Agents", description: "Adjust supply to avoid shortages/overstock." },
      { title: "Supplier Sourcing Agents", description: "Find new vendors and compare quotes." },
      { title: "Warehouse Automation Agents", description: "Assign robots or staff to tasks efficiently." },
      { title: "Customs Clearance Agents", description: "Automate import/export paperwork." },
    ],
  },
  {
    name: "Education",
    emoji: "🎓",
    icon: GraduationCap,
    services: [
      { title: "Personal Learning Agents", description: "Adapt lessons to each student’s pace." },
      { title: "Assignment Grading Agents", description: "Check homework and provide instant feedback." },
      { title: "Research Assistants", description: "Find and summarize academic papers." },
      { title: "Tutoring Bots", description: "Answer questions in real time for students." },
      { title: "Student Retention Agents", description: "Flag at-risk students based on performance data." },
    ],
  },
  {
    name: "Manufacturing",
    emoji: "🏭",
    icon: Cog,
    services: [
      { title: "Quality Control Agents", description: "Inspect products with AI vision." },
      { title: "Predictive Maintenance Agents", description: "Detect equipment issues before failure." },
      { title: "Production Scheduling Agents", description: "Optimize shifts and machine use." },
      { title: "Cost Reduction Agents", description: "Suggest energy or material savings." },
      { title: "R&D Simulation Agents", description: "Test designs virtually before production." },
    ],
  },
  {
    name: "Hospitality & Tourism",
    emoji: "🏨",
    icon: BedDouble,
    services: [
      { title: "Reservation Agents", description: "Handle bookings and cancellations." },
      { title: "Upsell Agents", description: "Suggest premium rooms or add-ons." },
      { title: "Guest Feedback Agents", description: "Monitor reviews & auto-respond." },
      { title: "Travel Planning Agents", description: "Create full itineraries for customers." },
      { title: "Dynamic Pricing Agents", description: "Adjust rates based on demand." },
    ],
  },
  {
    name: "Legal",
    emoji: "⚖️",
    icon: Scale,
    services: [
      { title: "Case Law Research Agents", description: "Find relevant precedents instantly." },
      { title: "Contract Review Agents", description: "Highlight risky clauses." },
      { title: "Client Intake Agents", description: "Collect initial case info automatically." },
      { title: "Deadline Tracking Agents", description: "Ensure court filings are on time." },
      { title: "Billing & Time Tracking Agents", description: "Log work hours without manual entry." },
    ],
  },
  {
    name: "Creative Industries",
    emoji: "🎨",
    icon: Palette,
    services: [
      { title: "Video Editing Agents", description: "Auto-cut, caption, and color-grade clips." },
      { title: "Music Composition Agents", description: "Generate backing tracks for ads." },
      { title: "Scriptwriting Agents", description: "Write scripts for YouTube/TikTok." },
      { title: "Design Assistant Agents", description: "Suggest brand-consistent visuals." },
      { title: "Trend Monitoring Agents", description: "Find upcoming styles & cultural shifts." },
    ],
  },
  {
    name: "Nonprofit & Government",
    emoji: "🏛️",
    icon: Landmark,
    services: [
      { title: "Grant Writing Agents", description: "Draft proposals based on templates." },
      { title: "Donor Management Agents", description: "Track and follow up with contributors." },
      { title: "Crisis Response Agents", description: "Coordinate volunteers in emergencies." },
      { title: "Public Information Agents", description: "Answer citizen FAQs." },
      { title: "Policy Analysis Agents", description: "Summarize bills & regulations." },
    ],
  },
];

const IndustryAgentsSection: FC = () => {
  return (
    <section id="industry-specific-ai-call-agents" className="section-padding bg-muted/30">
      <div className="container-width">
        <header className="text-center-all space-y-3 mb-8 md:mb-12">
          <ScrollAnimation>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold">
              Industry-Specific AI Agents
            </h2>
            <p className="text-sm sm:text-base text-muted-foreground max-w-3xl mx-auto">
              Tailored AI-powered solutions designed to meet the needs of your industry.
            </p>
            <hr className="mt-4 border-border w-24 mx-auto" />
          </ScrollAnimation>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
          {industries.map((industry, idx) => {
            const Icon = industry.icon;
            return (
              <ScrollAnimation key={idx}>
                <article className="group bg-card border border-border rounded-lg p-6 md:p-7 shadow-elegant focus-within:ring-2 focus-within:ring-primary/40">
                  <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] md:items-center gap-5">
                    {/* Icon (mobile first) */}
                    <figure
                      className="order-1 md:order-2 flex md:block items-center justify-start"
                      aria-label={`${industry.name} icon`}
                    >
                      <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-primary/10 text-primary flex items-center justify-center transition-transform duration-200 group-hover:scale-105">
                        <Icon className="w-8 h-8 md:w-10 md:h-10" aria-hidden="true" />
                        <span className="sr-only">{industry.name} icon</span>
                      </div>
                    </figure>

                    {/* Content */}
                    <div className="order-2 md:order-1">
                      <h3 className="text-lg md:text-xl font-semibold mb-3 md:mb-4">
                        <span>
                          {industry.name} {industry.emoji}
                        </span>
                      </h3>

                      <ul className="space-y-2 md:space-y-2.5">
                        {industry.services.map((service, sIdx) => (
                          <li key={sIdx} className="flex items-start gap-2.5">
                            <ChevronRight className="w-4 h-4 mt-0.5 text-primary flex-shrink-0" aria-hidden="true" />
                            <p className="text-sm leading-relaxed">
                              <span className="font-semibold">{service.title}</span> – {service.description} <em className="text-muted-foreground/80 italic">(Custom Pricing)</em>
                            </p>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </article>
              </ScrollAnimation>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default IndustryAgentsSection;
