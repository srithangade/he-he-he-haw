import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { X, Cookie } from 'lucide-react';
import { ConsentState, saveConsent } from '@/lib/analytics';

const DEFAULT_CONSENT: ConsentState = {
  necessary: true,
  analytics: false,
  marketing: false,
};

const CookieConsent = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [consent, setConsent] = useState<ConsentState>(DEFAULT_CONSENT);

  useEffect(() => {
    // Check if user has already made a choice
    const saved = localStorage.getItem('cookieConsentV2');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as ConsentState;
        setConsent({ ...DEFAULT_CONSENT, ...parsed });
        setIsVisible(false);
        return;
      } catch {}
    }
    setIsVisible(true);
  }, []);

  const acceptAll = () => {
    const updated: ConsentState = { necessary: true, analytics: true, marketing: true };
    saveConsent(updated);
    setIsVisible(false);
  };

  const declineNonEssential = () => {
    const updated: ConsentState = { necessary: true, analytics: false, marketing: false };
    saveConsent(updated);
    setIsVisible(false);
  };

  const savePreferences = () => {
    const updated: ConsentState = { ...consent, necessary: true };
    saveConsent(updated);
    setIsVisible(false);
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 pointer-events-none">
      <Card className="pointer-events-auto w-96 max-w-[95vw] bg-card border border-border shadow-elegant animate-slide-in-right">
        <div className="p-6">
          <div className="flex items-start gap-3">
            <Cookie className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
            <div className="flex-1">
              <h3 className="font-semibold text-card-foreground mb-2">
                Privacy & Cookies
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                We use cookies to make our site work and to improve your experience. Choose what we can use below. We’ll respect your choices.
              </p>

              <div className="space-y-3 mb-4">
                <div className="flex items-center justify-between py-2 px-3 rounded-md bg-secondary/40">
                  <div>
                    <div className="font-medium">Necessary</div>
                    <div className="text-xs text-muted-foreground">Required for the site to function.</div>
                  </div>
                  <Switch checked disabled aria-readonly aria-label="Necessary cookies" />
                </div>

                <div className="flex items-center justify-between py-2 px-3 rounded-md bg-secondary/40">
                  <div>
                    <div className="font-medium">Analytics</div>
                    <div className="text-xs text-muted-foreground">Helps us measure and improve performance.</div>
                  </div>
                  <Switch
                    checked={!!consent.analytics}
                    onCheckedChange={(v) => setConsent((c) => ({ ...c, analytics: !!v }))}
                    aria-label="Analytics cookies"
                  />
                </div>

                <div className="flex items-center justify-between py-2 px-3 rounded-md bg-secondary/40">
                  <div>
                    <div className="font-medium">Marketing</div>
                    <div className="text-xs text-muted-foreground">Personalization and ads (Google consent).</div>
                  </div>
                  <Switch
                    checked={!!consent.marketing}
                    onCheckedChange={(v) => setConsent((c) => ({ ...c, marketing: !!v }))}
                    aria-label="Marketing cookies"
                  />
                </div>
              </div>

              <div className="flex gap-2 flex-wrap">
                <Button onClick={savePreferences} size="sm" className="hero-button">
                  Save preferences
                </Button>
                <Button onClick={acceptAll} variant="outline" size="sm" className="outline-button">
                  Accept all
                </Button>
                <Button onClick={declineNonEssential} variant="outline" size="sm" className="outline-button">
                  Decline non‑essential
                </Button>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="h-6 w-6 text-muted-foreground hover:text-foreground"
              aria-label="Close cookie notice"
           >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default CookieConsent;
