import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, LogIn, UserPlus, User, LogOut } from "lucide-react";
import { Button } from "./ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "./ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import type { Session } from "@supabase/supabase-js";
const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [session, setSession] = useState<Session | null>(null);
  const location = useLocation();
  
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Auth state listener
  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
      }
    );

    return () => subscription.unsubscribe();
  }, []);
  const navigation = [{
    name: "Home",
    href: "/"
  }, {
    name: "About Us",
    href: "/about"
  }, {
    name: "Services",
    href: "/services"
  }, {
    name: "Contact",
    href: "/contact"
  }, {
    name: "Testimonials",
    href: "/testimonials"
  }, {
    name: "Gallery",
    href: "/gallery"
  }, {
    name: "FAQs",
    href: "/faqs"
  }];
  const isActive = (path: string) => location.pathname === path;
  const handleNavClick = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const handleSignOut = async () => {
    try {
      // Clean up auth state
      Object.keys(localStorage).forEach((key) => {
        if (key.startsWith('supabase.auth.') || key.includes('sb-')) {
          localStorage.removeItem(key);
        }
      });
      
      // Attempt global sign out
      try {
        await supabase.auth.signOut({ scope: 'global' });
      } catch (err) {
        // Ignore errors
      }
      
      toast({
        title: "Signed out",
        description: "You have been successfully signed out.",
      });
      
      // Force page reload for clean state
      window.location.href = '/';
    } catch (error: any) {
      toast({
        title: "Sign out failed", 
        description: error.message || "An unexpected error occurred.",
        variant: "destructive",
      });
    }
  };
  return <header className={`sticky top-0 z-50 transition-all duration-300 ${isScrolled ? "bg-background/95 backdrop-blur-sm shadow-elegant" : "bg-background"}`}>
      <div className="w-full px-2">
        <div className="flex items-center justify-between h-16">
          {/* Logo - Positioned far left */}
          <Link to="/" onClick={handleNavClick} className="flex items-center gap-2 hover:scale-105 transition-transform duration-300 z-10 absolute left-4">
            <img src="/favicon-32x32.png" alt="PriceAction favicon logo" className="h-6 w-6" width={24} height={24} />
            <span className="font-bold text-xl text-stone-950">PriceAction</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center justify-center flex-1">
            <div className="flex items-center space-x-8">
              {navigation.map(item => <Link key={item.name} to={item.href} onClick={handleNavClick} className={`nav-link ${isActive(item.href) ? "active" : ""}`}>
                  {item.name}
                </Link>)}
            </div>
          </nav>

          {/* Mobile Navigation - Improved */}
          <nav className="md:hidden flex items-center justify-center flex-1">
            <div className="flex items-center space-x-2 overflow-x-auto max-w-xs">
              {navigation.slice(0, 3).map(item => <Link key={item.name} to={item.href} onClick={handleNavClick} className={`nav-link text-xs whitespace-nowrap px-2 py-1 min-h-[44px] flex items-center ${isActive(item.href) ? "active" : ""}`}>
                  {item.name}
                </Link>)}
            </div>
          </nav>

          {/* Auth Section - Desktop */}
          <div className="hidden md:flex items-center space-x-3 absolute right-4">
            {session ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="flex items-center gap-2">
                    <User size={16} />
                    {session.user.user_metadata?.full_name || session.user.email}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={handleSignOut}>
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Button variant="default" size="sm" asChild>
                  <Link to="/auth" className="flex items-center gap-2" data-cta="header_sign_in">
                    <LogIn size={16} />
                     Sign In
                  </Link>
                </Button>
                <Button variant="default" size="sm" asChild>
                  <Link to="/auth" className="flex items-center gap-2" data-cta="header_sign_up">
                    <UserPlus size={16} />
                    Sign Up
                  </Link>
                </Button>
              </>
            )}
          </div>

          {/* Mobile menu button for overflow items - Larger touch target */}
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden p-3 min-h-[44px] min-w-[44px] hover:bg-accent rounded-lg transition-colors duration-300 flex items-center justify-center">
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation Overflow - Improved spacing and touch targets */}
        {isMenuOpen && <div className="md:hidden py-6 border-t border-border animate-fade-in">
            <nav className="flex flex-col space-y-2 px-4">
              {navigation.slice(3).map(item => <Link key={item.name} to={item.href} onClick={() => {
            setIsMenuOpen(false);
            handleNavClick();
          }} className={`nav-link py-3 px-4 text-center min-h-[44px] flex items-center justify-center rounded-lg hover:bg-accent transition-colors ${isActive(item.href) ? "active" : ""}`}>
                  {item.name}
                </Link>)}
              
              {/* Mobile Auth Section */}
              <div className="flex flex-col space-y-2 pt-4 border-t border-border mt-4">
                {session ? (
                  <>
                    <div className="text-sm text-center text-muted-foreground py-2">
                      {session.user.user_metadata?.full_name || session.user.email}
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => {
                      setIsMenuOpen(false);
                      handleSignOut();
                    }}>
                      <LogOut size={16} className="mr-2" />
                      Sign Out
                    </Button>
                  </>
                ) : (
                  <>
                    <Button variant="default" size="sm" asChild onClick={() => setIsMenuOpen(false)}>
                      <Link to="/auth" className="flex items-center justify-center gap-2" data-cta="header_sign_in_mobile">
                        <LogIn size={16} />
                        Sign In
                      </Link>
                    </Button>
                    <Button variant="default" size="sm" asChild onClick={() => setIsMenuOpen(false)}>
                      <Link to="/auth" className="flex items-center justify-center gap-2" data-cta="header_sign_up_mobile">
                        <UserPlus size={16} />
                        Sign Up
                      </Link>
                    </Button>
                  </>
                )}
              </div>
            </nav>
          </div>}
      </div>
    </header>;
};
export default Header;