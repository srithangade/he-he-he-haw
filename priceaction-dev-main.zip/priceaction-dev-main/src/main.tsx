import { createRoot } from 'react-dom/client'
import { StrictMode } from 'react'
import App from './App.tsx'
import './index.css'
import { initWebVitals } from './lib/webVitals'
import { initConsentMode, attachGlobalAnalyticsListeners, loadGA } from './lib/analytics'

// Initialize Consent Mode defaults ASAP
initConsentMode()

// Optionally load GA4 if you've stored an ID (set this once you have it)
const GA4_ID = localStorage.getItem('ga4Id') || ''
if (GA4_ID) {
  loadGA(GA4_ID)
}

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Root element not found");
}

createRoot(rootElement).render(
  <StrictMode>
    <App />
  </StrictMode>
);

// Initialize Web Vitals after app mounts
initWebVitals();

// Attach global analytics listeners (CTA clicks, chat opens, forms)
attachGlobalAnalyticsListeners();
