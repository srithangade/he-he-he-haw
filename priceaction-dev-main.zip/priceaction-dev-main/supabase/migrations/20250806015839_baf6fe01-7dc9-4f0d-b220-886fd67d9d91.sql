-- Drop the existing restrictive RLS policy that's blocking anonymous submissions
DROP POLICY IF EXISTS "Anyone can insert contact messages" ON contact_messages;

-- Create a new policy that allows anonymous contact form submissions
-- This is specifically for the contact form functionality which should work for anonymous users
CREATE POLICY "Allow anonymous contact form submissions" 
ON contact_messages 
FOR INSERT 
WITH CHECK (true);

-- Ensure the existing admin-only policies remain for reading, updating, and deleting
-- (These should already exist but let's make sure they're properly configured)
DROP POLICY IF EXISTS "Only admins can view contact messages" ON contact_messages;
CREATE POLICY "Only admins can view contact messages" 
ON contact_messages 
FOR SELECT 
USING (is_admin());

DROP POLICY IF EXISTS "Only admins can update contact messages" ON contact_messages;
CREATE POLICY "Only admins can update contact messages" 
ON contact_messages 
FOR UPDATE 
USING (is_admin());

DROP POLICY IF EXISTS "Only admins can delete contact messages" ON contact_messages;
CREATE POLICY "Only admins can delete contact messages" 
ON contact_messages 
FOR DELETE 
USING (is_admin());